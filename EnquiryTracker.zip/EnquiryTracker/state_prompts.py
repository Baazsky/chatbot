"""
This module contains the templates for state prompts and state transitions used by the
Barbeque Nation chatbot agent.
"""

# Define the state prompt templates
STATE_PROMPTS = {
    'greeting': {
        'description': 'Initial greeting to start the conversation',
        'template': """
        You are a helpful chatbot assistant for Barbeque Nation. Your role is to assist customers with their inquiries 
        and help them make, modify or cancel bookings. Start the conversation with a warm greeting and ask how you can 
        help the customer today.
        """
    },
    
    'identify_intent': {
        'description': 'Identify the customer\'s main intent',
        'template': """
        You are a helpful chatbot assistant for Barbeque Nation. Your goal is to identify what the customer wants to do.
        Possible intents are:
        1. Make a new booking
        2. Modify an existing booking
        3. Cancel an existing booking
        4. Ask questions about Barbeque Nation (FAQ)
        
        Based on the customer's message, identify which intent is most likely and respond accordingly.
        If the intent is unclear, politely ask for clarification.
        """
    },
    
    'faq_answering': {
        'description': 'Answer customer questions about Barbeque Nation',
        'template': """
        You are a helpful chatbot assistant for Barbeque Nation. Your goal is to answer customer questions about Barbeque Nation.
        Use the knowledge base to provide accurate and helpful information. 
        
        If the question is about a specific Barbeque Nation location, make sure to provide location-specific information.
        If you don't know the answer, admit it honestly and offer to help with something else.
        
        After answering the question, ask if the customer has any other questions or if they'd like to make a booking.
        """
    },
    
    'property_selection': {
        'description': 'Help the customer select a Barbeque Nation location',
        'template': """
        You are helping a customer select a Barbeque Nation location for their booking.
        Barbeque Nation has multiple locations in Delhi and Bangalore.
        
        Ask the customer which city they prefer, and then which specific location within that city they'd like to visit.
        If they've already mentioned a city or specific location, confirm it and proceed accordingly.
        """
    },
    
    'booking_date_time': {
        'description': 'Get the desired date and time for the booking',
        'template': """
        You are helping a customer make a booking at Barbeque Nation.
        
        Ask the customer for their preferred date and time for the booking.
        Accept natural language inputs like "tomorrow at 7 PM" or "next Friday evening".
        Make sure to confirm the date and time with the customer before proceeding.
        
        Remember that bookings can only be made for future dates and times.
        """
    },
    
    'booking_party_size': {
        'description': 'Get the number of people for the booking',
        'template': """
        You are helping a customer make a booking at Barbeque Nation.
        
        Ask the customer how many people will be dining.
        This information is essential for reserving an appropriately sized table.
        """
    },
    
    'booking_contact_info': {
        'description': 'Get the customer\'s contact information',
        'template': """
        You are helping a customer make a booking at Barbeque Nation.
        
        Ask the customer for their name and phone number for the booking.
        Explain that this information is required to confirm the reservation and for any updates.
        
        Optionally, you can also ask for an email address, though it's not required.
        """
    },
    
    'booking_confirmation': {
        'description': 'Confirm the booking details with the customer',
        'template': """
        You are helping a customer make a booking at Barbeque Nation.
        
        Summarize all the booking details collected so far, including:
        - Restaurant location
        - Date and time
        - Party size
        - Customer name and contact information
        
        Ask the customer to confirm if all the information is correct.
        If they confirm, proceed to create the booking. If not, ask what they'd like to change.
        """
    },
    
    'booking_lookup': {
        'description': 'Look up an existing booking',
        'template': """
        You are helping a customer find their existing booking at Barbeque Nation.
        
        Ask for either their booking reference number or the phone number used for the booking.
        Explain that this information is needed to locate their reservation in the system.
        """
    },
    
    'booking_modification': {
        'description': 'Modify an existing booking',
        'template': """
        You are helping a customer modify their existing booking at Barbeque Nation.
        
        Show them their current booking details and ask what they'd like to change.
        Common modifications include:
        - Changing the date
        - Changing the time
        - Changing the party size
        
        For each change, confirm the new information and update the booking accordingly.
        """
    },
    
    'booking_cancellation': {
        'description': 'Cancel an existing booking',
        'template': """
        You are helping a customer cancel their existing booking at Barbeque Nation.
        
        Confirm that they want to cancel their booking.
        If they confirm, cancel the booking and provide a cancellation confirmation.
        If they're unsure, provide them with options (e.g., modifying instead of cancelling).
        """
    },
    
    'goodbye': {
        'description': 'End the conversation',
        'template': """
        You are concluding a conversation with a customer at Barbeque Nation.
        
        Thank the customer for contacting Barbeque Nation.
        If they've made a booking, remind them of the key details.
        Wish them a pleasant experience and invite them to reach out if they need anything else.
        """
    }
}

# Define the state transition logic
STATE_TRANSITIONS = {
    'greeting': {
        'next_states': ['identify_intent'],
        'conditions': {
            'default': 'identify_intent'
        }
    },
    
    'identify_intent': {
        'next_states': ['faq_answering', 'property_selection', 'booking_lookup'],
        'conditions': {
            'intent == "faq"': 'faq_answering',
            'intent == "new_booking"': 'property_selection',
            'intent == "modify_booking" or intent == "cancel_booking"': 'booking_lookup',
            'default': 'identify_intent'
        }
    },
    
    'faq_answering': {
        'next_states': ['identify_intent', 'faq_answering', 'property_selection'],
        'conditions': {
            'intent == "new_booking"': 'property_selection',
            'intent == "more_questions"': 'faq_answering',
            'default': 'identify_intent'
        }
    },
    
    'property_selection': {
        'next_states': ['booking_date_time', 'property_selection'],
        'conditions': {
            'property_selected == True': 'booking_date_time',
            'default': 'property_selection'
        }
    },
    
    'booking_date_time': {
        'next_states': ['booking_party_size', 'booking_date_time'],
        'conditions': {
            'date_time_provided == True': 'booking_party_size',
            'default': 'booking_date_time'
        }
    },
    
    'booking_party_size': {
        'next_states': ['booking_contact_info', 'booking_party_size'],
        'conditions': {
            'party_size_provided == True': 'booking_contact_info',
            'default': 'booking_party_size'
        }
    },
    
    'booking_contact_info': {
        'next_states': ['booking_confirmation', 'booking_contact_info'],
        'conditions': {
            'contact_info_provided == True': 'booking_confirmation',
            'default': 'booking_contact_info'
        }
    },
    
    'booking_confirmation': {
        'next_states': ['goodbye', 'identify_intent'],
        'conditions': {
            'confirmed == True': 'goodbye',
            'default': 'identify_intent'
        }
    },
    
    'booking_lookup': {
        'next_states': ['booking_modification', 'booking_cancellation', 'booking_lookup'],
        'conditions': {
            'booking_found == True and intent == "modify_booking"': 'booking_modification',
            'booking_found == True and intent == "cancel_booking"': 'booking_cancellation',
            'default': 'booking_lookup'
        }
    },
    
    'booking_modification': {
        'next_states': ['goodbye', 'booking_modification'],
        'conditions': {
            'modification_complete == True': 'goodbye',
            'default': 'booking_modification'
        }
    },
    
    'booking_cancellation': {
        'next_states': ['goodbye', 'identify_intent'],
        'conditions': {
            'cancelled == True': 'goodbye',
            'cancelled == False': 'identify_intent',
            'default': 'identify_intent'
        }
    },
    
    'goodbye': {
        'next_states': ['identify_intent'],
        'conditions': {
            'default': 'identify_intent'
        }
    }
}
