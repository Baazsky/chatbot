import random
import string
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

def generate_booking_reference():
    """
    Generate a unique booking reference in the format BBQ-XXXXXX
    where X is an uppercase letter or digit.
    
    Returns:
        str: A unique booking reference
    """
    # Generate a 6-character random string of uppercase letters and digits
    chars = string.ascii_uppercase + string.digits
    random_str = ''.join(random.choices(chars, k=6))
    
    # Format as BBQ-XXXXXX
    return f"BBQ-{random_str}"

def format_phone_number(phone_number):
    """
    Format a phone number to a standard format (10 digits).
    
    Args:
        phone_number (str): The input phone number
    
    Returns:
        str: The formatted phone number
    """
    # Remove any non-digit characters
    digits_only = ''.join(c for c in phone_number if c.isdigit())
    
    # Check if it's a valid 10-digit phone number
    if len(digits_only) != 10:
        logger.warning(f"Invalid phone number format: {phone_number}")
    
    return digits_only

def parse_date(date_str):
    """
    Parse a date string into a datetime.date object.
    
    Args:
        date_str (str): The date string to parse
    
    Returns:
        datetime.date: The parsed date, or None if parsing fails
    """
    try:
        # Try common date formats
        formats = [
            '%Y-%m-%d',      # 2023-08-15
            '%d/%m/%Y',      # 15/08/2023
            '%d-%m-%Y',      # 15-08-2023
            '%d %B %Y',      # 15 August 2023
            '%d %b %Y',      # 15 Aug 2023
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(date_str, fmt).date()
            except ValueError:
                continue
        
        # If no format matches, log a warning and return None
        logger.warning(f"Could not parse date: {date_str}")
        return None
    
    except Exception as e:
        logger.error(f"Error parsing date: {str(e)}")
        return None

def parse_time(time_str):
    """
    Parse a time string into a datetime.time object.
    
    Args:
        time_str (str): The time string to parse
    
    Returns:
        datetime.time: The parsed time, or None if parsing fails
    """
    try:
        # Try common time formats
        formats = [
            '%H:%M',         # 14:30
            '%I:%M %p',      # 2:30 PM
            '%I:%M%p',       # 2:30PM
            '%I %p',         # 2 PM
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(time_str, fmt).time()
            except ValueError:
                continue
        
        # If no format matches, log a warning and return None
        logger.warning(f"Could not parse time: {time_str}")
        return None
    
    except Exception as e:
        logger.error(f"Error parsing time: {str(e)}")
        return None

def get_conversation_duration(start_time, end_time=None):
    """
    Calculate the duration of a conversation in seconds.
    
    Args:
        start_time (datetime): The start time of the conversation
        end_time (datetime, optional): The end time of the conversation. 
                                      If None, current time is used.
    
    Returns:
        float: The duration in seconds
    """
    if end_time is None:
        end_time = datetime.now()
    
    return (end_time - start_time).total_seconds()

def mask_phone_number(phone_number):
    """
    Mask a phone number for privacy (show only last 4 digits).
    
    Args:
        phone_number (str): The phone number to mask
    
    Returns:
        str: The masked phone number
    """
    if not phone_number or len(phone_number) < 4:
        return phone_number
    
    # Show only the last 4 digits
    return 'XXXX-XX' + phone_number[-4:]
