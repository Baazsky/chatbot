# Barbeque Nation Chatbot

A conversational AI chatbot system for Barbeque Nation that handles FAQs, new bookings, and booking modifications for properties in Delhi and Bangalore.

## Table of Contents

- [Overview](#overview)
- [Features](#features)
- [System Architecture](#system-architecture)
- [Technology Stack](#technology-stack)
- [Project Structure](#project-structure)
- [VSCode Setup](#vscode-setup)
- [Installation and Setup](#installation-and-setup)
- [Configuration](#configuration)
- [Usage](#usage)
- [Development](#development)
- [API Documentation](#api-documentation)
- [Deployment](#deployment)

## Overview

This project implements a conversational AI system for Barbeque Nation restaurants to handle customer inquiries, bookings, and booking modifications. The system features a state-based conversation flow that guides customers through various processes like answering FAQs, creating new bookings, and modifying/cancelling existing bookings.

## Features

- 🤖 **AI-Powered Conversation Flow**: Uses state machines to guide natural conversations
- 📋 **FAQ Answering**: Answers common restaurant-related questions using a knowledge base
- 🍽️ **Booking Management**: Create, modify, and cancel restaurant bookings
- 🏙️ **Multi-location Support**: Manage bookings for properties in Delhi and Bangalore 
- 📱 **Voice Integration**: Integration with Retell.ai for voice-based conversations
- 📊 **Analytics Dashboard**: Track conversations, bookings, and conversion rates
- 🧠 **Knowledge Base Management**: Easy-to-use interface for managing restaurant FAQs

## System Architecture

The system consists of the following components:

1. **Web Interface**: A Flask web application providing the admin dashboard and user interface
2. **Conversation Engine**: State-based conversation flow management
3. **Knowledge Base**: Structured FAQ storage with search capabilities
4. **Database**: SQLite/PostgreSQL for storing properties, bookings, and conversations
5. **Retell Integration**: API integration with Retell.ai for voice-based conversations

### Architecture Diagram

```
┌─────────────────────────┐     ┌────────────────────┐
│                         │     │                    │
│  Web Interface (Flask)  │◄────┤  User / Customer   │
│                         │     │                    │
└───────────┬─────────────┘     └────────────────────┘
            │
            ▼
┌─────────────────────────┐     ┌────────────────────┐
│                         │     │                    │
│  Conversation Engine    │◄────┤  State Definitions │
│  (State Machine)        │     │  & Transitions     │
│                         │     │                    │
└───────────┬─────────────┘     └────────────────────┘
            │
            ▼
┌──────────────────────────────────────────────────┐
│                                                  │
│                     Database                     │
│                                                  │
│  ┌────────────┐  ┌─────────┐  ┌───────────────┐  │
│  │ Properties │  │ Bookings│  │ Conversations │  │
│  └────────────┘  └─────────┘  └───────────────┘  │
│                                                  │
│  ┌────────────┐  ┌─────────────────────────────┐ │
│  │    FAQs    │  │ Conversation Logs & States  │ │
│  └────────────┘  └─────────────────────────────┘ │
│                                                  │
└──────────────────────────────────────────────────┘
            │
            ▼
┌─────────────────────────┐     ┌────────────────────┐
│                         │     │                    │
│    Knowledge Base       │◄────┤  External APIs     │
│    (FAQ Search)         │     │  (Retell.ai, etc.) │
│                         │     │                    │
└─────────────────────────┘     └────────────────────┘
```

## VSCode Setup

This project is configured to work seamlessly with Visual Studio Code. To get started:

1. **Install Required Extensions**: 
   - When you open this project in VSCode, you'll be prompted to install recommended extensions
   - Key extensions: Python, Pylance, Flask, Jinja

2. **Run the Application**:
   - Open the `run.py` file
   - Click the "Run" button in the top-right corner of VSCode
   - Or use the Debug panel (F5) and select "Python: Run Directly"

3. **Environment Variables**:
   - The project uses a `.env` file for local environment variables
   - Make sure to add your API keys (OPENAI_API_KEY, RETELL_API_KEY) to this file

4. **Debugging**:
   - Debugging configurations are already set up in `.vscode/launch.json`
   - Use the "Python: Flask" configuration for Flask debugging
   - Use the "Python: Run Directly" configuration for direct script execution

## Installation and Setup

### Prerequisites

- Python 3.8 or higher
- PostgreSQL (for production, SQLite available for development)
- Git (for version control)

### Installation Steps

1. **Clone the repository**:
   ```bash
   git clone https://github.com/your-username/bbq-nation-chatbot.git
   cd bbq-nation-chatbot
   ```

2. **Create and activate a virtual environment**:
   ```bash
   python -m venv venv
   
   # On Windows
   venv\Scripts\activate
   
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure environment variables**:
   Create a `.env` file in the project root with:
   ```
   # Database
   DATABASE_URL=postgresql://username:password@localhost:5432/bbq_nation_db
   
   # API Keys
   OPENAI_API_KEY=your_openai_api_key
   RETELL_API_KEY=your_retell_api_key
   
   # Flask
   FLASK_APP=run.py
   FLASK_ENV=development
   SECRET_KEY=your_secret_key
   ```

5. **Initialize the database**:
   ```bash
   # With SQLite (Development)
   flask db init
   flask db migrate -m "Initial migration"
   flask db upgrade
   
   # With PostgreSQL (Production)
   # Make sure PostgreSQL is running and the database exists
   flask db init
   flask db migrate -m "Initial migration"
   flask db upgrade
   ```

6. **Start the application**:
   ```bash
   # Using Flask directly
   flask run --host=0.0.0.0
   
   # Using Gunicorn (production)
   gunicorn --bind 0.0.0.0:5000 main:app
   
   # Using the provided run.py script
   python run.py
   ```

## Configuration

### Environment Variables

The application uses the following environment variables:

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `DATABASE_URL` | Database connection URL | SQLite (`sqlite:///instance/bbq_nation.db`) | No |
| `OPENAI_API_KEY` | OpenAI API Key for AI functionality | None | Yes |
| `RETELL_API_KEY` | Retell.ai API Key for voice integration | None | Yes |
| `SECRET_KEY` | Flask secret key for session security | None | Yes |
| `FLASK_ENV` | Flask environment (development/production) | `development` | No |

## Usage

### Admin Dashboard

The admin dashboard is accessible at `/dashboard` and provides functionality to:

1. **Manage Properties**: Add, edit, or view properties (restaurants)
2. **Manage Bookings**: View, confirm, or cancel booking requests
3. **Knowledge Base**: Add or update FAQs for the chatbot to use
4. **Analytics**: View conversation analytics and booking conversion rates

### Chatbot Interface

The chatbot interface is accessible from the main page (`/`) and provides:

1. **Text-based Chat**: Standard web chat interface for customers
2. **Voice Integration**: Option to initiate a voice call using Retell.ai

### API Documentation

The application provides a RESTful API for integration with other systems:

#### Property Endpoints

| Endpoint | Method | Description | Parameters |
|----------|--------|-------------|------------|
| `/api/properties` | GET | Get all properties | `?city=<city>` (optional) |
| `/api/properties/<id>` | GET | Get property details | None |
| `/api/properties` | POST | Create new property | JSON body with property details |

#### Booking Endpoints

| Endpoint | Method | Description | Parameters |
|----------|--------|-------------|------------|
| `/api/bookings` | GET | Get all bookings | `?property_id=<id>` (optional) |
| `/api/bookings/<reference>` | GET | Get booking details | None |
| `/api/bookings` | POST | Create new booking | JSON body with booking details |
| `/api/bookings/<reference>` | PUT | Update booking | JSON body with updates |
| `/api/bookings/<reference>/cancel` | POST | Cancel booking | None |

#### Knowledge Base Endpoints

| Endpoint | Method | Description | Parameters |
|----------|--------|-------------|------------|
| `/api/kb/search` | GET | Search knowledge base | `?query=<query>&property_id=<id>&category=<category>` |
| `/api/faqs` | GET | Get all FAQs | `?property_id=<id>&category=<category>` (optional) |
| `/api/faqs` | POST | Create new FAQ | JSON body with FAQ details |
| `/api/categories` | GET | Get all FAQ categories | None |

#### Conversation Endpoints

| Endpoint | Method | Description | Parameters |
|----------|--------|-------------|------------|
| `/api/conversations` | GET | Get all conversations | Various filters available |
| `/api/conversations/<session_id>` | GET | Get conversation details | None |
| `/api/conversations` | POST | Create new conversation | JSON body with initial details |
| `/api/conversations/<session_id>/message` | POST | Send message to conversation | JSON body with message |
| `/api/conversations/<session_id>/end` | POST | End conversation | None |
| `/api/conversations/analytics` | GET | Get conversation analytics | `?period=<period>` (optional) |
| `/api/states` | GET | Get all available conversation states | None |

## Development

### Project Structure

```
bbq-nation-chatbot/
├── app.py                  # Application factory and database setup
├── main.py                 # Application entry point
├── run.py                  # VSCode entry point
├── models.py               # Database models
├── routes.py               # API routes and views
├── knowledge_base.py       # Knowledge base functionality
├── retell_client.py        # Retell.ai integration
├── state_machine.py        # Conversation state management
├── state_prompts.py        # Templates for conversation states
├── utils.py                # Utility functions
├── .env                    # Environment variables (not in git)
├── static/                 # Static assets
│   ├── css/                # Stylesheets
│   ├── js/                 # JavaScript files
│   │   ├── chatbot.js      # Chatbot frontend functionality
│   │   └── dashboard.js    # Dashboard functionality
│   └── img/                # Images
├── templates/              # Jinja2 templates
│   ├── index.html          # Main page with chatbot
│   ├── dashboard.html      # Admin dashboard
│   └── knowledge_base.html # Knowledge base management
└── instance/               # Application instance folder (database)
```

### Adding New Features

When adding new features, follow these guidelines:

1. **Database Changes**: Add models to `models.py` and run migrations
2. **API Endpoints**: Add routes to `routes.py` following the established pattern
3. **State Transitions**: Update state machine in `state_machine.py` for new conversation flows
4. **Knowledge Base**: Update `knowledge_base.py` for new FAQ functionality
5. **UI Components**: Add templates to `templates/` and static files to `static/`

## Deployment

This application can be deployed using various methods:

### Using Gunicorn (Recommended for Production)

```bash
gunicorn --bind 0.0.0.0:5000 --workers 4 main:app
```

### Using Docker

A Dockerfile is provided for containerized deployment:

```bash
docker build -t bbq-nation-chatbot .
docker run -p 5000:5000 --env-file .env bbq-nation-chatbot
```

### Database Considerations

For production, use PostgreSQL instead of SQLite:

1. Install PostgreSQL and create a database
2. Update the `DATABASE_URL` environment variable
3. Run migrations to create tables

