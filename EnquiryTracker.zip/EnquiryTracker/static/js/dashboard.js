/**
 * Dashboard functionality for Barbeque Nation Admin
 * 
 * This script handles the admin dashboard functionality including:
 * - Loading properties, bookings, and conversations
 * - Managing properties (add, edit, delete)
 * - Viewing and managing bookings
 * - Viewing conversation logs
 */

document.addEventListener('DOMContentLoaded', () => {
    // Initial loading of data
    loadDashboardStats();
    
    // Add event listeners for tab switching
    document.querySelectorAll('#dashboardTabs button').forEach(tab => {
        tab.addEventListener('shown.bs.tab', event => {
            const targetId = event.target.getAttribute('data-bs-target');
            
            if (targetId === '#bookings') {
                loadBookings();
            } else if (targetId === '#conversations') {
                loadConversations();
            }
        });
    });
});

// Load dashboard statistics
function loadDashboardStats() {
    // Load booking count
    fetch('/api/bookings/count')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                document.getElementById('bookingCount').textContent = data.data.count;
            }
        })
        .catch(error => {
            console.error('Error loading booking count:', error);
        });
    
    // Load FAQ count
    fetch('/api/faqs/count')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                document.getElementById('faqCount').textContent = data.data.count;
            }
        })
        .catch(error => {
            console.error('Error loading FAQ count:', error);
        });
    
    // Load conversation count
    fetch('/api/conversations/count')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                document.getElementById('conversationCount').textContent = data.data.count;
            }
        })
        .catch(error => {
            console.error('Error loading conversation count:', error);
        });
}

// Load bookings
function loadBookings() {
    const propertyId = document.getElementById('bookingPropertyFilter').value;
    let url = '/api/bookings';
    
    if (propertyId) {
        url += `?property_id=${propertyId}`;
    }
    
    fetch(url)
        .then(response => response.json())
        .then(data => {
            const tableBody = document.getElementById('bookingsTableBody');
            
            if (data.status === 'success' && Array.isArray(data.data)) {
                if (data.data.length === 0) {
                    tableBody.innerHTML = `
                        <tr>
                            <td colspan="7" class="text-center">No bookings found</td>
                        </tr>
                    `;
                    return;
                }
                
                let html = '';
                
                data.data.forEach(booking => {
                    const date = new Date(booking.date + 'T' + booking.time);
                    const formattedDate = date.toLocaleString();
                    
                    html += `
                        <tr>
                            <td>${booking.booking_reference}</td>
                            <td>${booking.property.name}</td>
                            <td>${booking.customer_name}<br><small>${booking.customer_phone}</small></td>
                            <td>${formattedDate}</td>
                            <td>${booking.party_size}</td>
                            <td>
                                <span class="badge ${getStatusBadgeClass(booking.status)}">${booking.status}</span>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-info me-1" onclick="viewBooking('${booking.booking_reference}')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </td>
                        </tr>
                    `;
                });
                
                tableBody.innerHTML = html;
            } else {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="7" class="text-center text-danger">Error loading bookings</td>
                    </tr>
                `;
            }
        })
        .catch(error => {
            console.error('Error loading bookings:', error);
            document.getElementById('bookingsTableBody').innerHTML = `
                <tr>
                    <td colspan="7" class="text-center text-danger">Error loading bookings</td>
                </tr>
            `;
        });
}

// Load conversations
function loadConversations() {
    const activeOnly = document.getElementById('conversationStatusFilter').value;
    let url = '/api/conversations';
    
    if (activeOnly === 'true' || activeOnly === 'false') {
        url += `?is_active=${activeOnly}`;
    }
    
    fetch(url)
        .then(response => response.json())
        .then(data => {
            const tableBody = document.getElementById('conversationsTableBody');
            
            if (data.status === 'success' && Array.isArray(data.data)) {
                if (data.data.length === 0) {
                    tableBody.innerHTML = `
                        <tr>
                            <td colspan="7" class="text-center">No conversations found</td>
                        </tr>
                    `;
                    return;
                }
                
                let html = '';
                
                data.data.forEach(conversation => {
                    const createdAt = new Date(conversation.created_at);
                    const formattedDate = createdAt.toLocaleString();
                    const propertyName = conversation.property ? conversation.property.name : 'Not specified';
                    
                    html += `
                        <tr>
                            <td>${conversation.session_id.substring(0, 8)}...</td>
                            <td>${conversation.customer_phone || 'Unknown'}</td>
                            <td>${conversation.current_state || 'Not started'}</td>
                            <td>${propertyName}</td>
                            <td>${formattedDate}</td>
                            <td>
                                <span class="badge ${conversation.is_active ? 'bg-success' : 'bg-danger'}">
                                    ${conversation.is_active ? 'Active' : 'Inactive'}
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-info" onclick="viewConversation('${conversation.session_id}')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </td>
                        </tr>
                    `;
                });
                
                tableBody.innerHTML = html;
            } else {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="7" class="text-center text-danger">Error loading conversations</td>
                    </tr>
                `;
            }
        })
        .catch(error => {
            console.error('Error loading conversations:', error);
            document.getElementById('conversationsTableBody').innerHTML = `
                <tr>
                    <td colspan="7" class="text-center text-danger">Error loading conversations</td>
                </tr>
            `;
        });
}

// View booking details
function viewBooking(reference) {
    fetch(`/api/bookings/${reference}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success' && data.data) {
                const booking = data.data;
                const date = new Date(booking.date + 'T' + booking.time);
                const formattedDate = date.toLocaleString();
                
                const bookingDetails = document.getElementById('bookingDetails');
                bookingDetails.innerHTML = `
                    <div class="mb-3">
                        <h6>Reference:</h6>
                        <p class="border rounded p-2">${booking.booking_reference}</p>
                    </div>
                    <div class="mb-3">
                        <h6>Restaurant:</h6>
                        <p class="border rounded p-2">${booking.property.name}</p>
                    </div>
                    <div class="mb-3">
                        <h6>Customer:</h6>
                        <p class="border rounded p-2">
                            ${booking.customer_name}<br>
                            Phone: ${booking.customer_phone}<br>
                            ${booking.customer_email ? 'Email: ' + booking.customer_email : ''}
                        </p>
                    </div>
                    <div class="mb-3">
                        <h6>Date & Time:</h6>
                        <p class="border rounded p-2">${formattedDate}</p>
                    </div>
                    <div class="mb-3">
                        <h6>Party Size:</h6>
                        <p class="border rounded p-2">${booking.party_size} people</p>
                    </div>
                    ${booking.special_requests ? `
                        <div class="mb-3">
                            <h6>Special Requests:</h6>
                            <p class="border rounded p-2">${booking.special_requests}</p>
                        </div>
                    ` : ''}
                    <div class="mb-3">
                        <h6>Status:</h6>
                        <p class="border rounded p-2">
                            <span class="badge ${getStatusBadgeClass(booking.status)}">${booking.status}</span>
                        </p>
                    </div>
                `;
                
                // Enable or disable cancel button based on status
                const cancelBtn = document.getElementById('cancelBookingBtn');
                if (booking.status === 'cancelled') {
                    cancelBtn.disabled = true;
                    cancelBtn.classList.add('d-none');
                } else {
                    cancelBtn.disabled = false;
                    cancelBtn.classList.remove('d-none');
                    cancelBtn.setAttribute('data-reference', booking.booking_reference);
                }
                
                // Show the modal
                const modal = new bootstrap.Modal(document.getElementById('viewBookingModal'));
                modal.show();
            } else {
                alert('Error: Failed to load booking details');
            }
        })
        .catch(error => {
            console.error('Error loading booking details:', error);
            alert('Error: Failed to load booking details');
        });
}

// View conversation details
function viewConversation(sessionId) {
    fetch(`/api/conversations/${sessionId}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success' && data.data) {
                const conversation = data.data.conversation;
                const logs = data.data.logs;
                
                // Format conversation info
                const createdAt = new Date(conversation.created_at);
                const updatedAt = new Date(conversation.updated_at);
                
                const conversationInfo = document.getElementById('conversationInfo');
                conversationInfo.innerHTML = `
                    <div class="row mb-2">
                        <div class="col-md-4"><strong>Session ID:</strong></div>
                        <div class="col-md-8">${conversation.session_id}</div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-md-4"><strong>Customer Phone:</strong></div>
                        <div class="col-md-8">${conversation.customer_phone || 'Not provided'}</div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-md-4"><strong>Current State:</strong></div>
                        <div class="col-md-8">${conversation.current_state || 'Not started'}</div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-md-4"><strong>Property:</strong></div>
                        <div class="col-md-8">${conversation.property ? conversation.property.name : 'Not specified'}</div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-md-4"><strong>Booking:</strong></div>
                        <div class="col-md-8">${conversation.booking ? conversation.booking.booking_reference : 'No booking created'}</div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-md-4"><strong>Status:</strong></div>
                        <div class="col-md-8">
                            <span class="badge ${conversation.is_active ? 'bg-success' : 'bg-danger'}">
                                ${conversation.is_active ? 'Active' : 'Inactive'}
                            </span>
                        </div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-md-4"><strong>Created:</strong></div>
                        <div class="col-md-8">${createdAt.toLocaleString()}</div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-md-4"><strong>Last Updated:</strong></div>
                        <div class="col-md-8">${updatedAt.toLocaleString()}</div>
                    </div>
                `;
                
                // Format conversation logs
                const conversationLog = document.getElementById('conversationLog');
                
                if (logs.length === 0) {
                    conversationLog.innerHTML = '<p class="text-center">No conversation logs found</p>';
                } else {
                    let html = '';
                    
                    logs.forEach(log => {
                        const timestamp = new Date(log.timestamp);
                        const sender = log.sender === 'user' ? 'Customer' : 'System';
                        const cssClass = log.sender === 'user' ? 'bg-primary text-white' : 'bg-dark text-white';
                        
                        html += `
                            <div class="mb-3">
                                <div class="d-flex justify-content-between">
                                    <small><strong>${sender}</strong> (${log.state || 'No state'})</small>
                                    <small>${timestamp.toLocaleString()}</small>
                                </div>
                                <div class="p-2 rounded ${cssClass}">
                                    ${log.message}
                                </div>
                            </div>
                        `;
                    });
                    
                    conversationLog.innerHTML = html;
                }
                
                // Show the modal
                const modal = new bootstrap.Modal(document.getElementById('viewConversationModal'));
                modal.show();
            } else {
                alert('Error: Failed to load conversation details');
            }
        })
        .catch(error => {
            console.error('Error loading conversation details:', error);
            alert('Error: Failed to load conversation details');
        });
}

// Save a new property
function saveProperty() {
    const name = document.getElementById('propertyName').value;
    const city = document.getElementById('propertyCity').value;
    const address = document.getElementById('propertyAddress').value;
    const contact = document.getElementById('propertyContact').value;
    const hours = document.getElementById('propertyHours').value;
    
    if (!name || !city || !address || !contact || !hours) {
        alert('Please fill in all fields');
        return;
    }
    
    const propertyData = {
        name,
        city,
        address,
        contact_number: contact,
        opening_hours: hours
    };
    
    fetch('/api/properties', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(propertyData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Close modal and reset form
            document.getElementById('propertyForm').reset();
            const modal = bootstrap.Modal.getInstance(document.getElementById('addPropertyModal'));
            modal.hide();
            
            // Reload the page to show the new property
            window.location.reload();
        } else {
            alert(`Error: ${data.message || 'Failed to add property'}`);
        }
    })
    .catch(error => {
        console.error('Error adding property:', error);
        alert('An error occurred while adding the property');
    });
}

// Edit a property
function editProperty(id) {
    // Implementation would be similar to viewBooking but with the property data
    // and would open an edit modal
    alert('Edit property functionality to be implemented');
}

// Delete a property
function deleteProperty(id) {
    if (!confirm('Are you sure you want to delete this property? This will also delete all associated bookings and FAQs.')) {
        return;
    }
    
    fetch(`/api/properties/${id}`, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            alert('Property deleted successfully');
            window.location.reload();
        } else {
            alert(`Error: ${data.message || 'Failed to delete property'}`);
        }
    })
    .catch(error => {
        console.error('Error deleting property:', error);
        alert('An error occurred while deleting the property');
    });
}

// Cancel a booking
function cancelBooking() {
    const reference = document.getElementById('cancelBookingBtn').getAttribute('data-reference');
    
    if (!reference) {
        return;
    }
    
    if (!confirm('Are you sure you want to cancel this booking?')) {
        return;
    }
    
    fetch(`/api/bookings/${reference}/cancel`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            alert('Booking cancelled successfully');
            
            // Close the modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('viewBookingModal'));
            modal.hide();
            
            // Reload bookings
            loadBookings();
        } else {
            alert(`Error: ${data.message || 'Failed to cancel booking'}`);
        }
    })
    .catch(error => {
        console.error('Error cancelling booking:', error);
        alert('An error occurred while cancelling the booking');
    });
}

// Helper function to get the appropriate badge class for a booking status
function getStatusBadgeClass(status) {
    switch (status) {
        case 'confirmed':
            return 'bg-success';
        case 'cancelled':
            return 'bg-danger';
        case 'modified':
            return 'bg-warning';
        default:
            return 'bg-secondary';
    }
}