/**
 * Knowledge Base Management for Barbeque Nation Chatbot
 * 
 * This script handles the knowledge base management functionality including:
 * - Filtering and searching FAQs
 * - Adding new FAQs
 * - Editing existing FAQs
 * - Deleting FAQs
 */

document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const propertyFilter = document.getElementById('propertyFilter');
    const categoryFilter = document.getElementById('categoryFilter');
    const searchQuery = document.getElementById('searchQuery');
    const applyFiltersBtn = document.getElementById('applyFilters');
    const faqList = document.getElementById('faqList');
    const faqCount = document.getElementById('faqCount');
    
    // Add FAQ form
    const addFaqForm = document.getElementById('addFaqForm');
    const faqQuestion = document.getElementById('faqQuestion');
    const faqAnswer = document.getElementById('faqAnswer');
    const faqCategory = document.getElementById('faqCategory');
    const faqProperty = document.getElementById('faqProperty');
    const isGeneral = document.getElementById('isGeneral');
    const saveFaqBtn = document.getElementById('saveFaqBtn');
    
    // Edit FAQ form
    const editFaqForm = document.getElementById('editFaqForm');
    const editFaqId = document.getElementById('editFaqId');
    const editFaqQuestion = document.getElementById('editFaqQuestion');
    const editFaqAnswer = document.getElementById('editFaqAnswer');
    const editFaqCategory = document.getElementById('editFaqCategory');
    const editFaqProperty = document.getElementById('editFaqProperty');
    const editIsGeneral = document.getElementById('editIsGeneral');
    const updateFaqBtn = document.getElementById('updateFaqBtn');
    const deleteFaqBtn = document.getElementById('deleteFaqBtn');
    
    // Delete confirmation
    const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
    
    // Bootstrap modals
    const addFaqModal = new bootstrap.Modal(document.getElementById('addFaqModal'));
    const editFaqModal = new bootstrap.Modal(document.getElementById('editFaqModal'));
    const deleteFaqModal = new bootstrap.Modal(document.getElementById('deleteFaqModal'));
    
    // Load FAQs on page load
    loadFAQs();
    
    // Add event listeners
    applyFiltersBtn.addEventListener('click', loadFAQs);
    saveFaqBtn.addEventListener('click', saveFAQ);
    updateFaqBtn.addEventListener('click', updateFAQ);
    deleteFaqBtn.addEventListener('click', function() {
        deleteFaqModal.show();
    });
    confirmDeleteBtn.addEventListener('click', deleteFAQ);
    
    // Property checkbox interaction
    isGeneral.addEventListener('change', function() {
        if (this.checked) {
            faqProperty.disabled = true;
            faqProperty.value = "";
        } else {
            faqProperty.disabled = false;
        }
    });
    
    editIsGeneral.addEventListener('change', function() {
        if (this.checked) {
            editFaqProperty.disabled = true;
            editFaqProperty.value = "";
        } else {
            editFaqProperty.disabled = false;
        }
    });
    
    /**
     * Load FAQs based on current filters
     */
    function loadFAQs() {
        // Get filter values
        const property = propertyFilter.value;
        const category = categoryFilter.value;
        const query = searchQuery.value.trim();
        
        // Construct API URL with query parameters
        let url = '/api/knowledge-base/faqs?';
        if (property) {
            if (property === 'general') {
                url += 'is_general=true&';
            } else {
                url += `property_id=${property}&`;
            }
        }
        if (category) {
            url += `category=${category}&`;
        }
        
        // Show loading indicator
        faqList.innerHTML = `
            <div class="text-center my-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-3">Loading FAQs...</p>
            </div>
        `;
        
        // Fetch FAQs from API
        fetch(url)
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    displayFAQs(data.data, query);
                } else {
                    faqList.innerHTML = `
                        <div class="alert alert-danger">
                            Error loading FAQs: ${data.message}
                        </div>
                    `;
                }
            })
            .catch(error => {
                console.error('Error fetching FAQs:', error);
                faqList.innerHTML = `
                    <div class="alert alert-danger">
                        Error loading FAQs. Please try again later.
                    </div>
                `;
            });
    }
    
    /**
     * Display FAQs in the list
     * @param {Array} faqs - Array of FAQ objects
     * @param {string} searchQuery - Search query to filter by
     */
    function displayFAQs(faqs, searchQuery) {
        // Filter FAQs by search query if provided
        if (searchQuery) {
            const query = searchQuery.toLowerCase();
            faqs = faqs.filter(faq => 
                faq.question.toLowerCase().includes(query) || 
                faq.answer.toLowerCase().includes(query)
            );
        }
        
        // Update FAQ count
        faqCount.textContent = faqs.length;
        
        // If no FAQs found
        if (faqs.length === 0) {
            faqList.innerHTML = `
                <div class="text-center my-5">
                    <i class="fas fa-search fa-3x mb-3 text-secondary"></i>
                    <p>No FAQs found. Try changing your filters or add a new FAQ.</p>
                </div>
            `;
            return;
        }
        
        // Sort FAQs by category
        faqs.sort((a, b) => a.category.localeCompare(b.category));
        
        // Generate HTML for each FAQ
        let html = '';
        let currentCategory = '';
        
        faqs.forEach(faq => {
            // Add category header if category changes
            if (faq.category !== currentCategory) {
                currentCategory = faq.category;
                html += `
                    <div class="category-header mt-4 mb-3">
                        <h5 class="text-primary">${capitalizeFirstLetter(currentCategory)}</h5>
                        <hr>
                    </div>
                `;
            }
            
            // Property label
            let propertyLabel = '';
            if (faq.is_general) {
                propertyLabel = '<span class="badge bg-info me-2">General</span>';
            } else if (faq.property_id) {
                propertyLabel = `<span class="badge bg-secondary me-2">Property #${faq.property_id}</span>`;
            }
            
            html += `
                <div class="card faq-card" data-faq-id="${faq.id}">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div>
                                ${propertyLabel}
                                <span class="badge bg-primary category-badge">${faq.category}</span>
                            </div>
                            <button class="btn btn-sm btn-outline-primary edit-faq-btn" data-faq-id="${faq.id}">
                                <i class="fas fa-edit"></i>
                            </button>
                        </div>
                        <div class="faq-question">${escapeHtml(faq.question)}</div>
                        <div class="faq-answer">${escapeHtml(faq.answer).replace(/\n/g, '<br>')}</div>
                    </div>
                </div>
            `;
        });
        
        // Update FAQ list
        faqList.innerHTML = html;
        
        // Add event listeners to edit buttons
        document.querySelectorAll('.edit-faq-btn').forEach(button => {
            button.addEventListener('click', function() {
                const faqId = this.getAttribute('data-faq-id');
                openEditFAQModal(faqId);
            });
        });
    }
    
    /**
     * Save a new FAQ
     */
    function saveFAQ() {
        // Validate form
        if (!validateForm(addFaqForm)) {
            return;
        }
        
        // Get form values
        const question = faqQuestion.value.trim();
        const answer = faqAnswer.value.trim();
        const category = faqCategory.value;
        const propertyId = isGeneral.checked ? null : (faqProperty.value || null);
        const isGeneralValue = isGeneral.checked;
        
        // Disable save button
        saveFaqBtn.disabled = true;
        saveFaqBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...';
        
        // Send API request
        fetch('/api/knowledge-base/faqs', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                question: question,
                answer: answer,
                category: category,
                property_id: propertyId,
                is_general: isGeneralValue
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Reset form and close modal
                addFaqForm.reset();
                addFaqModal.hide();
                
                // Show success message
                showAlert('FAQ added successfully!', 'success');
                
                // Reload FAQs
                loadFAQs();
            } else {
                showAlert(`Error: ${data.message}`, 'danger');
            }
        })
        .catch(error => {
            console.error('Error adding FAQ:', error);
            showAlert('Error adding FAQ. Please try again.', 'danger');
        })
        .finally(() => {
            // Re-enable save button
            saveFaqBtn.disabled = false;
            saveFaqBtn.innerHTML = 'Save FAQ';
        });
    }
    
    /**
     * Open edit FAQ modal and populate with FAQ data
     * @param {string} faqId - ID of the FAQ to edit
     */
    function openEditFAQModal(faqId) {
        // Get FAQ data from the DOM
        const faqCard = document.querySelector(`.card[data-faq-id="${faqId}"]`);
        
        if (!faqCard) {
            console.error('FAQ card not found:', faqId);
            return;
        }
        
        // Set FAQ ID in hidden field
        editFaqId.value = faqId;
        
        // Get FAQ data from API for more complete information
        fetch(`/api/knowledge-base/faqs?id=${faqId}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success' && data.data.length > 0) {
                    const faq = data.data[0];
                    
                    // Populate form
                    editFaqQuestion.value = faq.question;
                    editFaqAnswer.value = faq.answer;
                    editFaqCategory.value = faq.category;
                    editFaqProperty.value = faq.property_id || '';
                    editIsGeneral.checked = faq.is_general;
                    
                    // Update property field based on is_general
                    if (faq.is_general) {
                        editFaqProperty.disabled = true;
                    } else {
                        editFaqProperty.disabled = false;
                    }
                    
                    // Show modal
                    editFaqModal.show();
                } else {
                    // Use data from DOM as fallback
                    editFaqQuestion.value = faqCard.querySelector('.faq-question').textContent;
                    editFaqAnswer.value = faqCard.querySelector('.faq-answer').innerHTML.replace(/<br>/g, '\n');
                    editFaqCategory.value = faqCard.querySelector('.category-badge').textContent;
                    editIsGeneral.checked = faqCard.querySelector('.badge.bg-info') !== null;
                    
                    if (editIsGeneral.checked) {
                        editFaqProperty.disabled = true;
                        editFaqProperty.value = '';
                    } else {
                        editFaqProperty.disabled = false;
                        const propertyBadge = faqCard.querySelector('.badge.bg-secondary');
                        if (propertyBadge) {
                            const propertyId = propertyBadge.textContent.replace('Property #', '');
                            editFaqProperty.value = propertyId;
                        } else {
                            editFaqProperty.value = '';
                        }
                    }
                    
                    // Show modal
                    editFaqModal.show();
                }
            })
            .catch(error => {
                console.error('Error fetching FAQ details:', error);
                
                // Use data from DOM as fallback
                editFaqQuestion.value = faqCard.querySelector('.faq-question').textContent;
                editFaqAnswer.value = faqCard.querySelector('.faq-answer').innerHTML.replace(/<br>/g, '\n');
                editFaqCategory.value = faqCard.querySelector('.category-badge').textContent;
                editIsGeneral.checked = faqCard.querySelector('.badge.bg-info') !== null;
                
                // Show modal
                editFaqModal.show();
            });
    }
    
    /**
     * Update an existing FAQ
     */
    function updateFAQ() {
        // Validate form
        if (!validateForm(editFaqForm)) {
            return;
        }
        
        // Get form values
        const faqId = editFaqId.value;
        const question = editFaqQuestion.value.trim();
        const answer = editFaqAnswer.value.trim();
        const category = editFaqCategory.value;
        const propertyId = editIsGeneral.checked ? null : (editFaqProperty.value || null);
        const isGeneralValue = editIsGeneral.checked;
        
        // Disable update button
        updateFaqBtn.disabled = true;
        updateFaqBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Updating...';
        
        // Send API request
        fetch(`/api/knowledge-base/faqs/${faqId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                question: question,
                answer: answer,
                category: category,
                property_id: propertyId,
                is_general: isGeneralValue
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Close modal
                editFaqModal.hide();
                
                // Show success message
                showAlert('FAQ updated successfully!', 'success');
                
                // Reload FAQs
                loadFAQs();
            } else {
                showAlert(`Error: ${data.message}`, 'danger');
            }
        })
        .catch(error => {
            console.error('Error updating FAQ:', error);
            showAlert('Error updating FAQ. Please try again.', 'danger');
        })
        .finally(() => {
            // Re-enable update button
            updateFaqBtn.disabled = false;
            updateFaqBtn.innerHTML = 'Update FAQ';
        });
    }
    
    /**
     * Delete an FAQ
     */
    function deleteFAQ() {
        const faqId = editFaqId.value;
        
        // Disable delete button
        confirmDeleteBtn.disabled = true;
        confirmDeleteBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Deleting...';
        
        // Send API request
        fetch(`/api/knowledge-base/faqs/${faqId}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Close modals
                deleteFaqModal.hide();
                editFaqModal.hide();
                
                // Show success message
                showAlert('FAQ deleted successfully!', 'success');
                
                // Reload FAQs
                loadFAQs();
            } else {
                showAlert(`Error: ${data.message}`, 'danger');
            }
        })
        .catch(error => {
            console.error('Error deleting FAQ:', error);
            showAlert('Error deleting FAQ. Please try again.', 'danger');
        })
        .finally(() => {
            // Re-enable delete button
            confirmDeleteBtn.disabled = false;
            confirmDeleteBtn.innerHTML = 'Delete';
        });
    }
    
    /**
     * Validate a form
     * @param {HTMLFormElement} form - Form to validate
     * @returns {boolean} - True if valid, false otherwise
     */
    function validateForm(form) {
        // Check if required fields are filled
        let isValid = true;
        
        form.querySelectorAll('[required]').forEach(input => {
            if (!input.value.trim()) {
                input.classList.add('is-invalid');
                isValid = false;
            } else {
                input.classList.remove('is-invalid');
            }
        });
        
        return isValid;
    }
    
    /**
     * Show an alert message
     * @param {string} message - Alert message
     * @param {string} type - Alert type (success, danger, etc.)
     */
    function showAlert(message, type = 'info') {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        // Insert at the top of the page
        document.querySelector('.container').insertBefore(alertDiv, document.querySelector('.container').firstChild);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.parentNode.removeChild(alertDiv);
            }
        }, 5000);
    }
    
    /**
     * Escape HTML special characters
     * @param {string} text - Text to escape
     * @returns {string} - Escaped text
     */
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    /**
     * Capitalize the first letter of a string
     * @param {string} string - String to capitalize
     * @returns {string} - Capitalized string
     */
    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
});
