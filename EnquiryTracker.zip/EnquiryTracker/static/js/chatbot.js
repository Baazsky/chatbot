/**
 * Chatbot functionality for Barbeque Nation Chatbot
 * 
 * This script handles the chat interface functionality including:
 * - Initializing a conversation session
 * - Sending user messages
 * - Receiving bot responses
 * - Displaying typing indicators
 * - Managing the conversation state
 * - Starting and ending voice calls
 */

class BBQChatbot {
    constructor(options = {}) {
        this.inputElement = options.inputElement;
        this.sendButton = options.sendButton;
        this.chatBody = options.chatBody;
        this.callButton = options.callButton;
        this.endCallButton = options.endCallButton;
        
        this.sessionId = null;
        this.callId = null;
        this.isCallActive = false;
        
        this.setupEventListeners();
        this.initializeChat();
    }
    
    setupEventListeners() {
        this.sendButton.addEventListener('click', () => {
            this.sendUserMessage();
        });
        
        this.callButton.addEventListener('click', () => {
            this.startCall();
        });
        
        this.endCallButton.addEventListener('click', () => {
            this.endCall();
        });
    }
    
    initializeChat() {
        // Create a new conversation session
        fetch('/api/conversations', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({})
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                console.log('Conversation initialized:', data);
                this.sessionId = data.data.session_id;
                
                if (data.data.call_id) {
                    this.callId = data.data.call_id;
                }
            } else {
                console.error('Error initializing conversation:', data.message);
                this.addBotMessage('Sorry, I had trouble initializing our conversation. Please try refreshing the page.');
            }
        })
        .catch(error => {
            console.error('Error initializing conversation:', error);
            this.addBotMessage('Sorry, I had trouble initializing our conversation. Please try refreshing the page.');
        });
    }
    
    sendUserMessage() {
        const message = this.inputElement.value.trim();
        
        if (!message) {
            return;
        }
        
        // Clear the input field
        this.inputElement.value = '';
        
        // Add the user message to the chat
        this.addUserMessage(message);
        
        // Add typing indicator
        this.addTypingIndicator();
        
        this.processUserMessage(message);
    }
    
    processUserMessage(message) {
        if (!this.sessionId) {
            console.error('No session ID available');
            this.removeTypingIndicator();
            this.addBotMessage('Sorry, I had trouble processing your message. Please try refreshing the page.');
            return;
        }
        
        // Send the message to the server
        fetch(`/api/conversations/${this.sessionId}/message`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: message
            })
        })
        .then(response => response.json())
        .then(data => {
            // Remove typing indicator
            this.removeTypingIndicator();
            
            // Add the bot response to the chat
            if (data.status === 'success' && data.data) {
                this.addBotMessage(data.data.response);
                
                // If the conversation has ended, handle it
                if (data.data.state === 'goodbye') {
                    setTimeout(() => {
                        this.endConversation();
                    }, 2000);
                }
            } else if (data.status === 'error') {
                this.addBotMessage('Sorry, I encountered an error: ' + data.message);
            } else {
                // Fallback for unexpected response format
                this.addBotMessage(data.response || 'Sorry, I didn\'t understand that.');
            }
        })
        .catch(error => {
            console.error('Error sending message:', error);
            
            // Remove typing indicator
            this.removeTypingIndicator();
            
            // Add an error message
            this.addBotMessage('Sorry, I encountered an error processing your request. Please try again later.');
        });
    }
    
    addUserMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'message user-message';
        messageElement.innerHTML = `
            <div class="message-content">
                ${this.escapeHtml(message)}
            </div>
        `;
        
        this.chatBody.appendChild(messageElement);
        this.scrollToBottom();
    }
    
    addBotMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'message bot-message';
        messageElement.innerHTML = `
            <div class="message-content">
                ${message}
            </div>
        `;
        
        this.chatBody.appendChild(messageElement);
        this.scrollToBottom();
    }
    
    addTypingIndicator() {
        // Remove any existing typing indicators
        this.removeTypingIndicator();
        
        const typingElement = document.createElement('div');
        typingElement.className = 'typing-indicator';
        typingElement.id = 'typingIndicator';
        typingElement.innerHTML = `
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
        `;
        
        this.chatBody.appendChild(typingElement);
        this.scrollToBottom();
    }
    
    removeTypingIndicator() {
        const typingIndicator = document.getElementById('typingIndicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }
    
    scrollToBottom() {
        this.chatBody.scrollTop = this.chatBody.scrollHeight;
    }
    
    startCall() {
        if (!this.sessionId) {
            console.error('No session ID available');
            return;
        }
        
        if (this.isCallActive) {
            console.warn('Call is already active');
            return;
        }
        
        // Disable the call button during the request
        this.callButton.disabled = true;
        this.callButton.classList.add('button-disabled');
        
        // Add a bot message to indicate call is being started
        this.addBotMessage('Starting a voice call...');
        
        // Call the API to start a call
        fetch(`/api/conversations/${this.sessionId}/call`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                console.log('Call started:', data);
                this.callId = data.data.call_id;
                this.isCallActive = true;
                
                // Show the end call button
                this.callButton.classList.add('d-none');
                this.endCallButton.classList.remove('d-none');
                
                // Add a message to indicate call is connected
                this.addBotMessage('Voice call connected! You can now speak with me directly.');
                
                // Update the chat status
                document.getElementById('chatStatus').textContent = 'On Call';
                document.getElementById('chatStatus').classList.add('text-success');
            } else {
                console.error('Error starting call:', data.message);
                this.addBotMessage(`Sorry, I couldn't start the voice call: ${data.message}`);
                
                // Enable the call button again
                this.callButton.disabled = false;
                this.callButton.classList.remove('button-disabled');
            }
        })
        .catch(error => {
            console.error('Error starting call:', error);
            this.addBotMessage('Sorry, I had trouble starting the voice call. Please try again later.');
            
            // Enable the call button again
            this.callButton.disabled = false;
            this.callButton.classList.remove('button-disabled');
        });
    }
    
    endCall() {
        if (!this.callId) {
            console.error('No call ID available');
            return;
        }
        
        if (!this.isCallActive) {
            console.warn('No active call to end');
            return;
        }
        
        // Disable the end call button during the request
        this.endCallButton.disabled = true;
        this.endCallButton.classList.add('button-disabled');
        
        // Call the API to end the call
        fetch(`/api/conversations/${this.sessionId}/call/${this.callId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                console.log('Call ended:', data);
                this.isCallActive = false;
                
                // Show the call button and hide the end call button
                this.callButton.classList.remove('d-none');
                this.endCallButton.classList.add('d-none');
                
                // Enable the call button
                this.callButton.disabled = false;
                this.callButton.classList.remove('button-disabled');
                
                // Add a message to indicate call has ended
                this.addBotMessage('Voice call ended. You can continue typing if you have more questions.');
                
                // Update the chat status
                document.getElementById('chatStatus').textContent = 'Online';
                document.getElementById('chatStatus').classList.remove('text-success');
            } else {
                console.error('Error ending call:', data.message);
                this.addBotMessage(`Sorry, I had trouble ending the voice call: ${data.message}`);
                
                // Enable the end call button again
                this.endCallButton.disabled = false;
                this.endCallButton.classList.remove('button-disabled');
            }
        })
        .catch(error => {
            console.error('Error ending call:', error);
            this.addBotMessage('Sorry, I had trouble ending the voice call. Please try again later.');
            
            // Enable the end call button again
            this.endCallButton.disabled = false;
            this.endCallButton.classList.remove('button-disabled');
        });
    }
    
    endConversation() {
        if (!this.sessionId) {
            console.error('No session ID available');
            return;
        }
        
        // End any active calls
        if (this.isCallActive && this.callId) {
            this.endCall();
        }
        
        // Call the API to end the conversation
        fetch(`/api/conversations/${this.sessionId}/end`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            console.log('Conversation ended:', data);
            
            // Add a final message
            this.addBotMessage('This conversation has ended. Refresh the page to start a new conversation.');
            
            // Disable input
            this.inputElement.disabled = true;
            this.sendButton.disabled = true;
            this.callButton.disabled = true;
            
            // Update the chat status
            document.getElementById('chatStatus').textContent = 'Offline';
            document.getElementById('chatStatus').classList.add('text-danger');
        })
        .catch(error => {
            console.error('Error ending conversation:', error);
        });
    }
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}