import logging
import json
from collections import defaultdict
from models import FAQ, Property
from app import db

logger = logging.getLogger(__name__)

# In-memory knowledge base for faster lookups
knowledge_base = defaultdict(list)

def initialize_knowledge_base():
    """Initialize the knowledge base from the database."""
    logger.info("Initializing knowledge base...")
    
    # Clear the existing knowledge base
    knowledge_base.clear()
    
    # Load all FAQs from the database
    faqs = FAQ.query.all()
    
    for faq in faqs:
        add_faq(faq)
    
    logger.info(f"Knowledge base initialized with {len(faqs)} FAQs")

def add_faq(faq):
    """Add a FAQ to the knowledge base."""
    if isinstance(faq, FAQ):
        # Create a dict representation of the FAQ
        faq_dict = {
            'id': faq.id,
            'question': faq.question,
            'answer': faq.answer,
            'category': faq.category,
            'property_id': faq.property_id,
            'is_general': faq.is_general
        }
        
        # If it's a general FAQ, add it to the general knowledge base
        if faq.is_general:
            knowledge_base['general'].append(faq_dict)
        
        # Add the FAQ to the property-specific knowledge base
        if faq.property_id:
            property_key = f'property_{faq.property_id}'
            knowledge_base[property_key].append(faq_dict)
        
        # Add the FAQ to the category-specific knowledge base
        category_key = f'category_{faq.category}'
        knowledge_base[category_key].append(faq_dict)
    else:
        logger.error("Invalid FAQ object provided to add_faq")

def remove_faq(faq_id):
    """Remove a FAQ from the knowledge base."""
    # Iterate through all knowledge base lists and remove the FAQ
    for key in knowledge_base:
        knowledge_base[key] = [faq for faq in knowledge_base[key] if faq['id'] != faq_id]

def search_knowledge_base(query, property_id=None, category=None, max_results=5):
    """
    Search the knowledge base for relevant FAQs.
    
    Args:
        query (str): The user's question or search query
        property_id (int, optional): The property ID to filter by
        category (str, optional): The category to filter by
        max_results (int, optional): Maximum number of results to return
    
    Returns:
        list: List of matching FAQ dictionaries
    """
    query = query.lower()
    results = []
    
    # Create a list of keywords from the query
    query_keywords = query.split()
    
    # Define what sources to search
    sources = []
    
    if property_id:
        sources.append(f'property_{property_id}')
    sources.append('general')
    
    if category:
        sources.append(f'category_{category}')
    
    # Search each source
    for source in sources:
        if source in knowledge_base:
            for faq in knowledge_base[source]:
                # Calculate a simple relevance score based on keyword matching
                question_text = faq['question'].lower()
                question_keywords = question_text.split()
                
                # Count how many query keywords appear in the question
                matches = sum(1 for keyword in query_keywords if keyword in question_text)
                
                # If there are matches, add to results with the score
                if matches > 0:
                    results.append({
                        'faq': faq,
                        'score': matches
                    })
    
    # Remove duplicates and sort by score (descending)
    unique_results = {}
    for result in results:
        faq_id = result['faq']['id']
        if faq_id not in unique_results or result['score'] > unique_results[faq_id]['score']:
            unique_results[faq_id] = result
    
    # Convert back to list and sort
    sorted_results = sorted(
        unique_results.values(), 
        key=lambda x: x['score'], 
        reverse=True
    )
    
    # Return only the FAQ dictionaries, limited by max_results
    return [result['faq'] for result in sorted_results[:max_results]]

def export_knowledge_base(filename='knowledge_base_export.json'):
    """Export the knowledge base to a JSON file."""
    with open(filename, 'w') as f:
        json.dump(knowledge_base, f, indent=2)
    
    logger.info(f"Knowledge base exported to {filename}")

def import_knowledge_base(filename='knowledge_base_export.json'):
    """Import the knowledge base from a JSON file."""
    try:
        with open(filename, 'r') as f:
            imported_data = json.load(f)
        
        # Clear the existing knowledge base
        knowledge_base.clear()
        
        # Copy the imported data into the knowledge base
        for key, value in imported_data.items():
            knowledge_base[key] = value
        
        logger.info(f"Knowledge base imported from {filename}")
        
        # For each FAQ in the imported data, check if it exists in the database
        # If not, create it
        for source in imported_data.values():
            for faq_dict in source:
                # Check if the FAQ exists in the database by ID
                existing_faq = FAQ.query.get(faq_dict.get('id'))
                
                if not existing_faq:
                    # Create a new FAQ in the database
                    new_faq = FAQ(
                        question=faq_dict['question'],
                        answer=faq_dict['answer'],
                        category=faq_dict['category'],
                        property_id=faq_dict.get('property_id'),
                        is_general=faq_dict.get('is_general', False)
                    )
                    
                    db.session.add(new_faq)
        
        # Commit all new FAQs to the database
        db.session.commit()
        
    except Exception as e:
        logger.error(f"Error importing knowledge base: {str(e)}")
        raise

# Initialize the knowledge base when the module is loaded
try:
    initialize_knowledge_base()
except Exception as e:
    logger.warning(f"Could not initialize knowledge base: {str(e)}")
    logger.warning("Knowledge base will be initialized when the database is available")
