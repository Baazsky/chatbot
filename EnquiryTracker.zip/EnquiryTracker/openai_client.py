import os
import json
import logging
from openai import OpenAI

logger = logging.getLogger(__name__)

# Get the OpenAI API key from environment variables
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")

# Initialize the OpenAI client if API key is available
client = None
if OPENAI_API_KEY:
    client = OpenAI(api_key=OPENAI_API_KEY)
else:
    logger.warning("OPENAI_API_KEY not set. OpenAI functionality will be limited.")

def analyze_intent(user_message):
    """
    Analyze the user message to determine the user's intent.
    
    Args:
        user_message (str): The user's message
    
    Returns:
        dict: Dictionary with intent information
    """
    if not client:
        logger.warning("OpenAI client not initialized. Using fallback intent analysis.")
        # Simple fallback analysis using keywords
        message = user_message.lower()
        
        if any(word in message for word in ["book", "reservation", "reserve", "table"]):
            return {"intent": "booking", "confidence": 0.7}
        elif any(word in message for word in ["modify", "change", "update", "reschedule"]):
            return {"intent": "modification", "confidence": 0.7}
        elif any(word in message for word in ["cancel", "delete", "remove"]):
            return {"intent": "cancellation", "confidence": 0.7}
        elif any(word in message for word in ["time", "hour", "open", "close", "timing"]):
            return {"intent": "faq", "category": "hours", "confidence": 0.7}
        elif any(word in message for word in ["menu", "food", "dish", "price"]):
            return {"intent": "faq", "category": "menu", "confidence": 0.7}
        elif any(word in message for word in ["location", "address", "direction", "where"]):
            return {"intent": "faq", "category": "location", "confidence": 0.7}
        else:
            return {"intent": "greeting", "confidence": 0.5}
    
    try:
        # Create a structured system prompt to analyze the intent
        system_prompt = """
        Analyze the user message to determine their intent when interacting with a restaurant chatbot.
        Respond with a JSON object in this format:
        {
            "intent": "booking" | "modification" | "cancellation" | "faq" | "greeting" | "goodbye",
            "category": "menu" | "hours" | "location" | "pricing" | "general" (only for FAQ intent),
            "confidence": [0.0 to 1.0 value indicating confidence level]
        }
        
        - booking: User wants to make a new reservation
        - modification: User wants to change an existing booking
        - cancellation: User wants to cancel a booking
        - faq: User is asking a general question
        - greeting: User is saying hello or starting the conversation
        - goodbye: User is ending the conversation
        
        For FAQ intents, include a "category" field.
        """
        
        response = client.chat.completions.create(
            model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ],
            response_format={"type": "json_object"}
        )
        
        content = response.choices[0].message.content
        if content is None:
            logger.error("OpenAI returned None content")
            return {"intent": "greeting", "confidence": 0.3}
            
        # Convert the content to a string to ensure it's the right type for json.loads
        content_str = str(content)
        result = json.loads(content_str)
        logger.info(f"Intent analysis: {result}")
        return result
    
    except Exception as e:
        logger.error(f"Error analyzing intent with OpenAI: {str(e)}")
        return {"intent": "greeting", "confidence": 0.3}

def extract_entities(user_message, entity_types):
    """
    Extract specific entities from the user message.
    
    Args:
        user_message (str): The user's message
        entity_types (list): Types of entities to extract (date, time, party_size, name, phone, etc.)
    
    Returns:
        dict: Dictionary with extracted entities
    """
    if not client:
        logger.warning("OpenAI client not initialized. Using fallback entity extraction.")
        # Simple fallback extraction using basic patterns
        result = {}
        message = user_message.lower()
        
        # Very basic extractions as fallback
        if "party_size" in entity_types:
            # Look for numbers in the message
            words = message.split()
            for word in words:
                if word.isdigit():
                    result["party_size"] = int(word)
                    break
        
        return result
    
    try:
        # Create a system prompt based on requested entity types
        entity_descriptions = {
            "date": "Date for booking (YYYY-MM-DD format)",
            "time": "Time for booking (HH:MM format, 24-hour)",
            "party_size": "Number of people in the party (integer)",
            "name": "Customer's full name",
            "phone": "Customer's phone number",
            "email": "Customer's email address",
            "location": "City or specific restaurant location",
            "booking_reference": "Booking reference number (usually starts with BBQ-)"
        }
        
        entities_to_extract = {entity: entity_descriptions[entity] 
                              for entity in entity_types if entity in entity_descriptions}
        
        system_prompt = f"""
        Extract the following entities from the user message:
        {json.dumps(entities_to_extract, indent=2)}
        
        Respond with a JSON object where keys are entity names and values are the extracted values.
        If an entity is not found, do not include it in the response.
        """
        
        response = client.chat.completions.create(
            model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ],
            response_format={"type": "json_object"}
        )
        
        content = response.choices[0].message.content
        if content is None:
            logger.error("OpenAI returned None content")
            return {}
            
        # Convert the content to a string to ensure it's the right type for json.loads
        content_str = str(content)
        result = json.loads(content_str)
        logger.info(f"Entity extraction: {result}")
        return result
    
    except Exception as e:
        logger.error(f"Error extracting entities with OpenAI: {str(e)}")
        return {}

def generate_response(prompt, context=None):
    """
    Generate a natural language response using a template and context.
    
    Args:
        prompt (str): The template prompt
        context (dict, optional): Context variables to fill in the template
    
    Returns:
        str: The generated response
    """
    if not client:
        logger.warning("OpenAI client not initialized. Using template response.")
        # Just return the template with basic string formatting
        if context:
            try:
                return prompt.format(**context)
            except KeyError:
                return prompt
        return prompt
    
    try:
        # If context is provided, fill in the template first
        if context:
            try:
                filled_prompt = prompt.format(**context)
            except KeyError as e:
                logger.error(f"Error filling template: {str(e)}")
                filled_prompt = prompt
        else:
            filled_prompt = prompt
        
        system_prompt = """
        You are a helpful assistant for Barbeque Nation restaurant. 
        Generate a natural, conversational response based on the provided template.
        Keep the response concise, friendly, and helpful.
        """
        
        response = client.chat.completions.create(
            model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": filled_prompt}
            ],
            max_tokens=150
        )
        
        result = response.choices[0].message.content
        return result
    
    except Exception as e:
        logger.error(f"Error generating response with OpenAI: {str(e)}")
        return prompt