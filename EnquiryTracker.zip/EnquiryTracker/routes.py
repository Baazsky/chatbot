import os
import json
import uuid
from datetime import datetime, timedelta
from flask import render_template, request, jsonify, redirect, url_for, session
from app import db, logger
from models import Property, Booking, FAQ, Conversation, ConversationLog
from knowledge_base import search_knowledge_base, add_faq
from state_machine import process_user_input, get_available_states
from retell_client import create_call, end_call, update_call_state
from utils import generate_booking_reference

def register_routes(app):
    @app.route('/')
    def index():
        """Render the main landing page."""
        return render_template('index.html')
    
    @app.route('/dashboard')
    def dashboard():
        """Render the admin dashboard for managing properties, bookings, and FAQs."""
        properties = Property.query.all()
        return render_template('dashboard.html', properties=properties)
    
    @app.route('/knowledge-base')
    def knowledge_base_page():
        """Render the knowledge base management page."""
        properties = Property.query.all()
        categories = db.session.query(FAQ.category).distinct().all()
        categories = [category[0] for category in categories]
        
        return render_template('knowledge_base.html', properties=properties, categories=categories)
    
    @app.route('/api/properties', methods=['GET'])
    def get_properties():
        """Get all properties from the database."""
        properties = Property.query.all()
        return jsonify({
            'status': 'success',
            'data': [property.to_dict() for property in properties]
        })
    
    @app.route('/api/properties/<int:property_id>', methods=['GET'])
    def get_property(property_id):
        """Get a specific property by ID."""
        property = Property.query.get_or_404(property_id)
        return jsonify({
            'status': 'success',
            'data': property.to_dict()
        })
    
    @app.route('/api/properties', methods=['POST'])
    def create_property():
        """Create a new property."""
        data = request.json
        
        try:
            new_property = Property(
                name=data['name'],
                city=data['city'],
                address=data['address'],
                contact_number=data['contact_number'],
                opening_hours=data['opening_hours']
            )
            
            db.session.add(new_property)
            db.session.commit()
            
            return jsonify({
                'status': 'success',
                'message': 'Property created successfully',
                'data': new_property.to_dict()
            }), 201
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error creating property: {str(e)}")
            return jsonify({
                'status': 'error',
                'message': f'Error creating property: {str(e)}'
            }), 400
    
    @app.route('/api/bookings', methods=['GET'])
    def get_bookings():
        """Get all bookings or filter by property_id."""
        property_id = request.args.get('property_id')
        
        if property_id:
            bookings = Booking.query.filter_by(property_id=property_id).all()
        else:
            bookings = Booking.query.all()
        
        return jsonify({
            'status': 'success',
            'data': [booking.to_dict() for booking in bookings]
        })
    
    @app.route('/api/bookings/<string:booking_reference>', methods=['GET'])
    def get_booking(booking_reference):
        """Get a specific booking by reference."""
        booking = Booking.query.filter_by(booking_reference=booking_reference).first_or_404()
        return jsonify({
            'status': 'success',
            'data': booking.to_dict()
        })
    
    @app.route('/api/bookings', methods=['POST'])
    def create_booking():
        """Create a new booking."""
        data = request.json
        
        try:
            # Generate a unique booking reference
            booking_reference = generate_booking_reference()
            
            # Parse date and time
            booking_date = datetime.strptime(data['date'], '%Y-%m-%d').date()
            booking_time = datetime.strptime(data['time'], '%H:%M').time()
            
            new_booking = Booking(
                property_id=data['property_id'],
                customer_name=data['customer_name'],
                customer_phone=data['customer_phone'],
                customer_email=data.get('customer_email'),
                date=booking_date,
                time=booking_time,
                party_size=data['party_size'],
                special_requests=data.get('special_requests'),
                booking_reference=booking_reference
            )
            
            db.session.add(new_booking)
            db.session.commit()
            
            return jsonify({
                'status': 'success',
                'message': 'Booking created successfully',
                'data': new_booking.to_dict()
            }), 201
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error creating booking: {str(e)}")
            return jsonify({
                'status': 'error',
                'message': f'Error creating booking: {str(e)}'
            }), 400
    
    @app.route('/api/bookings/<string:booking_reference>', methods=['PUT'])
    def update_booking(booking_reference):
        """Update an existing booking."""
        booking = Booking.query.filter_by(booking_reference=booking_reference).first_or_404()
        data = request.json
        
        try:
            if 'date' in data:
                booking.date = datetime.strptime(data['date'], '%Y-%m-%d').date()
            
            if 'time' in data:
                booking.time = datetime.strptime(data['time'], '%H:%M').time()
            
            if 'party_size' in data:
                booking.party_size = data['party_size']
            
            if 'special_requests' in data:
                booking.special_requests = data['special_requests']
            
            if 'status' in data:
                booking.status = data['status']
            
            db.session.commit()
            
            return jsonify({
                'status': 'success',
                'message': 'Booking updated successfully',
                'data': booking.to_dict()
            })
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error updating booking: {str(e)}")
            return jsonify({
                'status': 'error',
                'message': f'Error updating booking: {str(e)}'
            }), 400
    
    @app.route('/api/bookings/<string:booking_reference>/cancel', methods=['PUT'])
    def cancel_booking(booking_reference):
        """Cancel a booking."""
        booking = Booking.query.filter_by(booking_reference=booking_reference).first_or_404()
        
        try:
            booking.status = 'cancelled'
            db.session.commit()
            
            return jsonify({
                'status': 'success',
                'message': 'Booking cancelled successfully',
                'data': booking.to_dict()
            })
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error cancelling booking: {str(e)}")
            return jsonify({
                'status': 'error',
                'message': f'Error cancelling booking: {str(e)}'
            }), 400
    
    @app.route('/api/knowledge-base/search', methods=['GET'])
    def search_kb():
        """Search the knowledge base for relevant information."""
        query = request.args.get('query', '')
        property_id = request.args.get('property_id')
        
        if not query:
            return jsonify({
                'status': 'error',
                'message': 'Query parameter is required'
            }), 400
        
        results = search_knowledge_base(query, property_id)
        
        return jsonify({
            'status': 'success',
            'data': results
        })
    
    @app.route('/api/knowledge-base/faqs', methods=['GET'])
    def get_faqs():
        """Get all FAQs or filter by property_id and/or category."""
        property_id = request.args.get('property_id')
        category = request.args.get('category')
        
        query = FAQ.query
        
        if property_id:
            # Get property-specific FAQs and general FAQs
            query = query.filter((FAQ.property_id == property_id) | (FAQ.is_general == True))
        
        if category:
            query = query.filter_by(category=category)
        
        faqs = query.all()
        
        return jsonify({
            'status': 'success',
            'data': [faq.to_dict() for faq in faqs]
        })
    
    @app.route('/api/knowledge-base/faqs', methods=['POST'])
    def create_faq():
        """Create a new FAQ."""
        data = request.json
        
        try:
            new_faq = FAQ(
                question=data['question'],
                answer=data['answer'],
                category=data['category'],
                property_id=data.get('property_id'),
                is_general=data.get('is_general', False)
            )
            
            db.session.add(new_faq)
            db.session.commit()
            
            # Add to the knowledge base for search
            add_faq(new_faq)
            
            return jsonify({
                'status': 'success',
                'message': 'FAQ created successfully',
                'data': new_faq.to_dict()
            }), 201
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error creating FAQ: {str(e)}")
            return jsonify({
                'status': 'error',
                'message': f'Error creating FAQ: {str(e)}'
            }), 400
    
    @app.route('/api/knowledge-base/categories', methods=['GET'])
    def get_categories():
        """Get all unique FAQ categories."""
        categories = db.session.query(FAQ.category).distinct().all()
        categories = [category[0] for category in categories]
        
        return jsonify({
            'status': 'success',
            'data': categories
        })
    
    @app.route('/api/conversations', methods=['GET'])
    def get_conversations():
        """Get all conversations or filter by various parameters."""
        property_id = request.args.get('property_id')
        is_active = request.args.get('is_active')
        
        query = Conversation.query
        
        if property_id:
            query = query.filter_by(property_id=property_id)
        
        if is_active is not None:
            is_active_bool = is_active.lower() == 'true'
            query = query.filter_by(is_active=is_active_bool)
        
        conversations = query.all()
        
        return jsonify({
            'status': 'success',
            'data': [conversation.to_dict() for conversation in conversations]
        })
    
    @app.route('/api/conversations/<string:session_id>', methods=['GET'])
    def get_conversation(session_id):
        """Get a specific conversation and its logs by session_id."""
        conversation = Conversation.query.filter_by(session_id=session_id).first_or_404()
        logs = ConversationLog.query.filter_by(conversation_id=conversation.id).order_by(ConversationLog.timestamp).all()
        
        result = conversation.to_dict()
        result['logs'] = [log.to_dict() for log in logs]
        
        return jsonify({
            'status': 'success',
            'data': result
        })
    
    @app.route('/api/conversations', methods=['POST'])
    def create_conversation():
        """Create a new conversation session."""
        data = request.json
        
        try:
            session_id = str(uuid.uuid4())
            
            new_conversation = Conversation(
                session_id=session_id,
                customer_phone=data.get('customer_phone'),
                current_state='greeting',
                property_id=data.get('property_id'),
                conversation_data={},
                is_active=True
            )
            
            db.session.add(new_conversation)
            db.session.commit()
            
            # Create a new call in Retell.ai
            call_id = create_call(session_id)
            
            if call_id:
                # Update conversation data with call_id
                new_conversation.conversation_data = {'call_id': call_id}
                db.session.commit()
            
            return jsonify({
                'status': 'success',
                'message': 'Conversation created successfully',
                'data': {
                    'session_id': session_id,
                    'call_id': call_id
                }
            }), 201
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error creating conversation: {str(e)}")
            return jsonify({
                'status': 'error',
                'message': f'Error creating conversation: {str(e)}'
            }), 400
    
    @app.route('/api/conversations/<string:session_id>/message', methods=['POST'])
    def process_message(session_id):
        """Process a user message in the conversation."""
        conversation = Conversation.query.filter_by(session_id=session_id).first_or_404()
        data = request.json
        
        if not conversation.is_active:
            return jsonify({
                'status': 'error',
                'message': 'This conversation is no longer active'
            }), 400
        
        user_message = data.get('message', '')
        
        if not user_message:
            return jsonify({
                'status': 'error',
                'message': 'Message content is required'
            }), 400
        
        try:
            # Log the user message
            user_log = ConversationLog(
                conversation_id=conversation.id,
                message=user_message,
                sender='user',
                state=conversation.current_state
            )
            db.session.add(user_log)
            
            # Process the user input and get the system response
            response, new_state = process_user_input(
                user_message, 
                conversation.current_state,
                conversation.conversation_data,
                conversation.property_id
            )
            
            # Update conversation state and data
            conversation.current_state = new_state
            db.session.commit()
            
            # Log the system response
            system_log = ConversationLog(
                conversation_id=conversation.id,
                message=response,
                sender='system',
                state=new_state
            )
            db.session.add(system_log)
            db.session.commit()
            
            # Update the call state in Retell.ai
            if conversation.conversation_data and 'call_id' in conversation.conversation_data:
                update_call_state(
                    conversation.conversation_data['call_id'],
                    new_state,
                    response
                )
            
            return jsonify({
                'status': 'success',
                'data': {
                    'response': response,
                    'state': new_state
                }
            })
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error processing message: {str(e)}")
            return jsonify({
                'status': 'error',
                'message': f'Error processing message: {str(e)}'
            }), 400
    
    @app.route('/api/conversations/<string:session_id>/call', methods=['POST'])
    def start_call(session_id):
        """Start a voice call for a conversation using Retell.ai."""
        conversation = Conversation.query.filter_by(session_id=session_id).first_or_404()
        
        if not conversation.is_active:
            return jsonify({
                'status': 'error',
                'message': 'This conversation is no longer active'
            }), 400
            
        try:
            # Call the Retell.ai API to create a call
            call_id = create_call(session_id)
            
            if not call_id:
                return jsonify({
                    'status': 'error',
                    'message': 'Failed to create call with Retell.ai'
                }), 500
                
            # Update the conversation with the call ID
            if not conversation.conversation_data:
                conversation.conversation_data = {}
                
            conversation.conversation_data['call_id'] = call_id
            db.session.commit()
            
            return jsonify({
                'status': 'success',
                'data': {
                    'call_id': call_id,
                    'message': 'Call started successfully'
                }
            })
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error starting call: {str(e)}")
            return jsonify({
                'status': 'error',
                'message': f'Error starting call: {str(e)}'
            }), 500
    
    @app.route('/api/conversations/<string:session_id>/call/<string:call_id>', methods=['DELETE'])
    def end_call(session_id, call_id):
        """End an active voice call for a conversation."""
        conversation = Conversation.query.filter_by(session_id=session_id).first_or_404()
        
        if not conversation.is_active:
            return jsonify({
                'status': 'error',
                'message': 'This conversation is no longer active'
            }), 400
            
        try:
            # Call the Retell.ai API to end the call
            success = end_call(call_id)
            
            if not success:
                return jsonify({
                    'status': 'error',
                    'message': 'Failed to end call with Retell.ai'
                }), 500
                
            return jsonify({
                'status': 'success',
                'data': {
                    'message': 'Call ended successfully'
                }
            })
        except Exception as e:
            logger.error(f"Error ending call: {str(e)}")
            return jsonify({
                'status': 'error',
                'message': f'Error ending call: {str(e)}'
            }), 500
    
    @app.route('/api/conversations/<string:session_id>/end', methods=['PUT'])
    def end_conversation(session_id):
        """End an active conversation."""
        conversation = Conversation.query.filter_by(session_id=session_id).first_or_404()
        
        if not conversation.is_active:
            return jsonify({
                'status': 'error',
                'message': 'This conversation is already inactive'
            }), 400
        
        try:
            conversation.is_active = False
            db.session.commit()
            
            # End the call in Retell.ai
            if conversation.conversation_data and 'call_id' in conversation.conversation_data:
                end_call(conversation.conversation_data['call_id'])
            
            return jsonify({
                'status': 'success',
                'message': 'Conversation ended successfully'
            })
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error ending conversation: {str(e)}")
            return jsonify({
                'status': 'error',
                'message': f'Error ending conversation: {str(e)}'
            }), 400
    
    @app.route('/api/analytics/conversations', methods=['GET'])
    def get_conversation_analytics():
        """Get analytics about conversations."""
        # Get the date range from query parameters
        start_date_str = request.args.get('start_date')
        end_date_str = request.args.get('end_date')
        
        try:
            if start_date_str:
                start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
            else:
                # Default to 30 days ago
                start_date = datetime.utcnow() - timedelta(days=30)
            
            if end_date_str:
                end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
            else:
                # Default to today
                end_date = datetime.utcnow()
                
            # Get conversations in the date range
            conversations = Conversation.query.filter(
                Conversation.created_at >= start_date,
                Conversation.created_at <= end_date
            ).all()
            
            # Compute analytics
            total_conversations = len(conversations)
            active_conversations = len([c for c in conversations if c.is_active])
            
            # Get the count of conversations that led to bookings
            conversations_with_bookings = len([c for c in conversations if c.booking_id is not None])
            
            # Get average conversation duration
            conversation_durations = []
            for conversation in conversations:
                if conversation.is_active:
                    # For active conversations, use current time as end time
                    duration = (datetime.utcnow() - conversation.created_at).total_seconds() / 60
                else:
                    # For inactive conversations, use the timestamp of the last log
                    last_log = ConversationLog.query.filter_by(conversation_id=conversation.id).order_by(ConversationLog.timestamp.desc()).first()
                    if last_log:
                        duration = (last_log.timestamp - conversation.created_at).total_seconds() / 60
                    else:
                        duration = 0
                conversation_durations.append(duration)
            
            avg_duration = sum(conversation_durations) / len(conversation_durations) if conversation_durations else 0
            
            return jsonify({
                'status': 'success',
                'data': {
                    'total_conversations': total_conversations,
                    'active_conversations': active_conversations,
                    'conversations_with_bookings': conversations_with_bookings,
                    'average_duration_minutes': avg_duration,
                    'date_range': {
                        'start_date': start_date.strftime('%Y-%m-%d'),
                        'end_date': end_date.strftime('%Y-%m-%d')
                    }
                }
            })
        except Exception as e:
            logger.error(f"Error getting conversation analytics: {str(e)}")
            return jsonify({
                'status': 'error',
                'message': f'Error getting conversation analytics: {str(e)}'
            }), 400
    
    @app.route('/api/states', methods=['GET'])
    def get_states():
        """Get all available conversation states."""
        states = get_available_states()
        
        return jsonify({
            'status': 'success',
            'data': states
        })
    
    @app.route('/api/bookings/count', methods=['GET'])
    def get_booking_count():
        """Get the total count of bookings."""
        return jsonify({
            'status': 'success',
            'data': {
                'count': Booking.query.count()
            }
        })
    
    @app.route('/api/faqs/count', methods=['GET'])
    def get_faq_count():
        """Get the total count of FAQs."""
        return jsonify({
            'status': 'success',
            'data': {
                'count': FAQ.query.count()
            }
        })
    
    @app.route('/api/conversations/count', methods=['GET'])
    def get_conversation_count():
        """Get the total count of conversations."""
        return jsonify({
            'status': 'success',
            'data': {
                'count': Conversation.query.count()
            }
        })
    
    # Return 404 for undefined routes
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({
            'status': 'error',
            'message': 'Resource not found'
        }), 404
    
    # Return 500 for server errors
    @app.errorhandler(500)
    def server_error(error):
        return jsonify({
            'status': 'error',
            'message': 'Internal server error'
        }), 500
