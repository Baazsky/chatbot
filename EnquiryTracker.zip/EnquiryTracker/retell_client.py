import os
import requests
import logging
import json
from datetime import datetime

logger = logging.getLogger(__name__)

# Get the Retell.ai API key from environment variables
API_KEY = os.environ.get("RETELL_API_KEY", "")

# Base URL for Retell.ai API
BASE_URL = "https://api.retell.ai/v1"

def create_call(session_id):
    """
    Create a new call using Retell.ai.
    
    Args:
        session_id (str): The session ID to associate with the call
    
    Returns:
        str: The call ID if successful, None otherwise
    """
    if not API_KEY:
        logger.warning("RETELL_API_KEY not set. Skipping create_call.")
        return None
    
    try:
        url = f"{BASE_URL}/calls"
        
        headers = {
            "Content-Type": "application/json",
            "x-api-key": API_KEY
        }
        
        payload = {
            "llm_agent_config": {
                "agent_name": "Barbeque Nation Assistant",
                "initial_message": "Hello! Welcome to Barbeque Nation. How can I assist you today?"
            },
            "reference_id": session_id,
            "webhook_url": "",  # Optional: add a webhook URL to receive call events
            "voice_config": {
                "voice_id": "female-voice-1",  # Change this to the desired voice ID
                "rate": 1.0,
                "pitch": 1.0
            }
        }
        
        response = requests.post(url, headers=headers, json=payload)
        
        if response.status_code == 200:
            data = response.json()
            call_id = data.get("call_id")
            logger.info(f"Created call with ID: {call_id}")
            return call_id
        else:
            logger.error(f"Failed to create call: {response.status_code} - {response.text}")
            return None
    
    except Exception as e:
        logger.error(f"Error creating call: {str(e)}")
        return None

def end_call(call_id):
    """
    End an ongoing call.
    
    Args:
        call_id (str): The ID of the call to end
    
    Returns:
        bool: True if successful, False otherwise
    """
    if not API_KEY:
        logger.warning("RETELL_API_KEY not set. Skipping end_call.")
        return False
    
    try:
        url = f"{BASE_URL}/calls/{call_id}/end"
        
        headers = {
            "Content-Type": "application/json",
            "x-api-key": API_KEY
        }
        
        response = requests.post(url, headers=headers)
        
        if response.status_code == 200:
            logger.info(f"Successfully ended call with ID: {call_id}")
            return True
        else:
            logger.error(f"Failed to end call: {response.status_code} - {response.text}")
            return False
    
    except Exception as e:
        logger.error(f"Error ending call: {str(e)}")
        return False

def update_call_state(call_id, state, response_text=None):
    """
    Update the state of an ongoing call.
    
    Args:
        call_id (str): The ID of the call to update
        state (str): The new state
        response_text (str, optional): The text to send as a response
    
    Returns:
        bool: True if successful, False otherwise
    """
    if not API_KEY:
        logger.warning("RETELL_API_KEY not set. Skipping update_call_state.")
        return False
    
    try:
        url = f"{BASE_URL}/calls/{call_id}/update"
        
        headers = {
            "Content-Type": "application/json",
            "x-api-key": API_KEY
        }
        
        payload = {
            "metadata": {
                "current_state": state,
                "last_updated": datetime.utcnow().isoformat()
            }
        }
        
        if response_text:
            payload["override_llm_response"] = response_text
        
        response = requests.post(url, headers=headers, json=payload)
        
        if response.status_code == 200:
            logger.info(f"Successfully updated call state for ID: {call_id}")
            return True
        else:
            logger.error(f"Failed to update call state: {response.status_code} - {response.text}")
            return False
    
    except Exception as e:
        logger.error(f"Error updating call state: {str(e)}")
        return False

def get_call_status(call_id):
    """
    Get the status of a call.
    
    Args:
        call_id (str): The ID of the call
    
    Returns:
        dict: The call status data if successful, None otherwise
    """
    if not API_KEY:
        logger.warning("RETELL_API_KEY not set. Skipping get_call_status.")
        return None
    
    try:
        url = f"{BASE_URL}/calls/{call_id}"
        
        headers = {
            "Content-Type": "application/json",
            "x-api-key": API_KEY
        }
        
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            logger.info(f"Retrieved call status for ID: {call_id}")
            return data
        else:
            logger.error(f"Failed to get call status: {response.status_code} - {response.text}")
            return None
    
    except Exception as e:
        logger.error(f"Error getting call status: {str(e)}")
        return None

def get_call_analytics(call_id):
    """
    Get analytics data for a call.
    
    Args:
        call_id (str): The ID of the call
    
    Returns:
        dict: The call analytics data if successful, None otherwise
    """
    if not API_KEY:
        logger.warning("RETELL_API_KEY not set. Skipping get_call_analytics.")
        return None
    
    try:
        url = f"{BASE_URL}/calls/{call_id}/analytics"
        
        headers = {
            "Content-Type": "application/json",
            "x-api-key": API_KEY
        }
        
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            logger.info(f"Retrieved call analytics for ID: {call_id}")
            return data
        else:
            logger.error(f"Failed to get call analytics: {response.status_code} - {response.text}")
            return None
    
    except Exception as e:
        logger.error(f"Error getting call analytics: {str(e)}")
        return None
