import os
import logging
from pathlib import Path

# Import dotenv for environment variables
try:
    from dotenv import load_dotenv
    # Load environment variables from .env file if it exists
    env_path = Path('.') / '.env'
    if env_path.exists():
        load_dotenv(dotenv_path=env_path)
except ImportError:
    # If python-dotenv is not installed, continue without it
    pass

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class Base(DeclarativeBase):
    pass

# Initialize SQLAlchemy with the Base class
db = SQLAlchemy(model_class=Base)

# Create the Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "barbeque_nation_chatbot_dev_key")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)  # Needed for url_for to generate with https

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///bbq_nation.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize the app with the extension
db.init_app(app)


def init_app():
    with app.app_context():
        # Import models to ensure tables are created
        import models  # noqa: F401
        
        # Create all database tables
        db.create_all()
        
        # Import and register routes
        from routes import register_routes
        register_routes(app)
       
        logger.info("Application initialized successfully")
        
    return app
if __name__ == "__main__":
    init_app()
    app.run(debug=True)
