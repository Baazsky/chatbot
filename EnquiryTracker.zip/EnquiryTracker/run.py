"""
VSCode entry point for running the Barbeque Nation Chatbot application.
Run this file to start the application in VSCode.
"""
from app import app, init_app

if __name__ == "__main__":
    # Initialize the application
    app = init_app()
    
    # Run the application with debug mode enabled
    app.run(host="0.0.0.0", port=5000, debug=True)