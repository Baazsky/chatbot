import logging
from datetime import datetime, timedelta
from models import Property, Booking, FAQ, Conversation
from app import db
from knowledge_base import search_knowledge_base
from state_prompts import STATE_PROMPTS, STATE_TRANSITIONS
from utils import generate_booking_reference
from openai_client import analyze_intent, extract_entities, generate_response

logger = logging.getLogger(__name__)

# Define all available states
AVAILABLE_STATES = [
    'greeting',
    'identify_intent',
    'faq_answering',
    'property_selection',
    'booking_date_time',
    'booking_party_size',
    'booking_contact_info',
    'booking_confirmation',
    'booking_lookup',
    'booking_modification',
    'booking_cancellation',
    'goodbye'
]

def get_available_states():
    """Return all available states with their descriptions."""
    return {
        state: STATE_PROMPTS.get(state, {}).get('description', 'No description available')
        for state in AVAILABLE_STATES
    }

def process_user_input(user_input, current_state, conversation_data, property_id=None):
    """
    Process user input based on the current state and return the system response and next state.
    
    Args:
        user_input (str): The user's message
        current_state (str): The current conversation state
        conversation_data (dict): The conversation context data
        property_id (int, optional): The current property ID if selected
    
    Returns:
        tuple: (system_response, new_state)
    """
    logger.debug(f"Processing user input in state {current_state}: {user_input}")
    
    # If no conversation_data is provided, initialize it
    if conversation_data is None:
        conversation_data = {}
    
    # Get the state prompt template
    state_prompt = STATE_PROMPTS.get(current_state)
    if not state_prompt:
        logger.error(f"State prompt not found for state: {current_state}")
        return "I'm sorry, I'm having trouble understanding. Let me restart.", 'greeting'
    
    # Process user input based on current state
    if current_state == 'greeting':
        # Simply move to identify_intent state
        response = "Hello! Welcome to Barbeque Nation. How can I assist you today? Are you looking to make a new booking, modify an existing booking, cancel a booking, or do you have questions about our restaurants?"
        new_state = 'identify_intent'
    
    elif current_state == 'identify_intent':
        # Identify user intent from their message
        intent = _identify_intent(user_input)
        logger.debug(f"Identified intent: {intent}")
        
        if intent == 'new_booking':
            response = "Great! I'd be happy to help you make a new booking. Would you like to book at one of our locations in Delhi or Bangalore?"
            new_state = 'property_selection'
            conversation_data['intent'] = 'new_booking'
        
        elif intent == 'modify_booking':
            response = "I can help you modify your existing booking. Could you please provide your booking reference number or the phone number used for the booking?"
            new_state = 'booking_lookup'
            conversation_data['intent'] = 'modify_booking'
        
        elif intent == 'cancel_booking':
            response = "I understand you want to cancel a booking. Could you please provide your booking reference number or the phone number used for the booking?"
            new_state = 'booking_lookup'
            conversation_data['intent'] = 'cancel_booking'
        
        elif intent == 'faq':
            response = "I'll be happy to answer your questions. What would you like to know about Barbeque Nation?"
            new_state = 'faq_answering'
            conversation_data['intent'] = 'faq'
        
        else:
            response = "I'm not sure I understand what you're looking for. Are you interested in making a new booking, modifying an existing booking, cancelling a booking, or do you have questions about our restaurants?"
            new_state = 'identify_intent'  # Stay in the same state
    
    elif current_state == 'faq_answering':
        # Search the knowledge base for the answer
        results = search_knowledge_base(user_input, property_id)
        
        if results:
            # Use the top result as the answer
            response = results[0]['answer']
            
            # Add a follow-up question
            response += "\n\nIs there anything else you'd like to know?"
            new_state = 'faq_answering'  # Stay in the same state
        else:
            response = "I'm sorry, I don't have specific information about that. Would you like to know about our menu, opening hours, or make a booking instead?"
            new_state = 'identify_intent'  # Go back to intent identification
    
    elif current_state == 'property_selection':
        # Extract city and property from user input
        city, property_name = _extract_location_info(user_input)
        
        if city:
            # Get properties in the city
            properties = Property.query.filter_by(city=city).all()
            
            if not properties:
                response = f"I'm sorry, we don't have any locations in {city} at the moment. We have restaurants in Delhi and Bangalore. Which city would you prefer?"
                new_state = 'property_selection'  # Stay in the same state
            elif len(properties) == 1:
                # Only one property in the city
                selected_property = properties[0]
                conversation_data['property_id'] = selected_property.id
                conversation_data['property_name'] = selected_property.name
                conversation_data['city'] = city
                
                response = f"Great! I've selected our {selected_property.name} location in {city}. When would you like to visit? Please provide a date and time (e.g., 'tomorrow at 7 PM' or '15th August at 8:30 PM')."
                new_state = 'booking_date_time'
            else:
                # Multiple properties in the city, check if a specific one was mentioned
                if property_name:
                    matching_properties = [p for p in properties if property_name.lower() in p.name.lower()]
                    
                    if matching_properties:
                        selected_property = matching_properties[0]
                        conversation_data['property_id'] = selected_property.id
                        conversation_data['property_name'] = selected_property.name
                        conversation_data['city'] = city
                        
                        response = f"Great! I've selected our {selected_property.name} location in {city}. When would you like to visit? Please provide a date and time (e.g., 'tomorrow at 7 PM' or '15th August at 8:30 PM')."
                        new_state = 'booking_date_time'
                    else:
                        # No matching property found
                        property_list = ", ".join([p.name for p in properties])
                        response = f"I couldn't find a location matching '{property_name}' in {city}. We have the following locations in {city}: {property_list}. Which one would you prefer?"
                        new_state = 'property_selection'  # Stay in the same state
                else:
                    # No specific property mentioned, list all in the city
                    property_list = ", ".join([p.name for p in properties])
                    response = f"We have multiple locations in {city}: {property_list}. Which one would you prefer?"
                    new_state = 'property_selection'  # Stay in the same state
        else:
            response = "I'm sorry, I couldn't determine which city you're interested in. We have restaurants in Delhi and Bangalore. Which city would you prefer?"
            new_state = 'property_selection'  # Stay in the same state
    
    elif current_state == 'booking_date_time':
        # Extract date and time from user input
        booking_date, booking_time = _extract_date_time(user_input)
        
        if booking_date and booking_time:
            # Store the date and time in conversation data
            conversation_data['booking_date'] = booking_date.strftime('%Y-%m-%d')
            conversation_data['booking_time'] = booking_time.strftime('%H:%M')
            
            # Check if the requested date/time is valid (not in the past)
            now = datetime.now()
            booking_datetime = datetime.combine(booking_date, booking_time)
            
            if booking_datetime < now:
                response = "I'm sorry, the date and time you requested is in the past. Could you please provide a future date and time?"
                new_state = 'booking_date_time'  # Stay in the same state
            else:
                response = f"Great! You've selected {booking_date.strftime('%A, %d %B %Y')} at {booking_time.strftime('%I:%M %p')}. How many people will be dining with you?"
                new_state = 'booking_party_size'
        else:
            response = "I'm sorry, I couldn't understand the date and time. Could you please provide it in a format like 'tomorrow at 7 PM' or '15th August at 8:30 PM'?"
            new_state = 'booking_date_time'  # Stay in the same state
    
    elif current_state == 'booking_party_size':
        # Extract party size from user input
        party_size = _extract_party_size(user_input)
        
        if party_size:
            # Store the party size in conversation data
            conversation_data['party_size'] = party_size
            
            response = f"Perfect! A table for {party_size} people. Could you please provide your name and contact phone number for the booking?"
            new_state = 'booking_contact_info'
        else:
            response = "I'm sorry, I couldn't determine the number of people. Could you please tell me how many people will be dining?"
            new_state = 'booking_party_size'  # Stay in the same state
    
    elif current_state == 'booking_contact_info':
        # Extract name and phone number from user input
        name, phone_number = _extract_contact_info(user_input)
        
        if name and phone_number:
            # Store the contact info in conversation data
            conversation_data['customer_name'] = name
            conversation_data['customer_phone'] = phone_number
            
            # Get the property information
            property_id = conversation_data.get('property_id')
            property_name = conversation_data.get('property_name')
            booking_date = conversation_data.get('booking_date')
            booking_time = conversation_data.get('booking_time')
            party_size = conversation_data.get('party_size')
            
            # Format the booking details for confirmation
            date_obj = datetime.strptime(booking_date, '%Y-%m-%d').date()
            time_obj = datetime.strptime(booking_time, '%H:%M').time()
            formatted_date = date_obj.strftime('%A, %d %B %Y')
            formatted_time = time_obj.strftime('%I:%M %p')
            
            response = f"Thank you, {name}. Here's a summary of your booking:\n\n" \
                       f"Restaurant: {property_name}\n" \
                       f"Date: {formatted_date}\n" \
                       f"Time: {formatted_time}\n" \
                       f"Party Size: {party_size} people\n" \
                       f"Name: {name}\n" \
                       f"Phone: {phone_number}\n\n" \
                       f"Is this information correct? Please reply with 'yes' to confirm or 'no' to make changes."
            
            new_state = 'booking_confirmation'
        else:
            response = "I need both your name and phone number to complete the booking. Could you please provide them?"
            new_state = 'booking_contact_info'  # Stay in the same state
    
    elif current_state == 'booking_confirmation':
        # Check if the user confirms the booking
        if _is_confirmation(user_input):
            # Create the booking in the database
            try:
                # Generate a unique booking reference
                booking_reference = generate_booking_reference()
                
                # Parse date and time
                booking_date = datetime.strptime(conversation_data['booking_date'], '%Y-%m-%d').date()
                booking_time = datetime.strptime(conversation_data['booking_time'], '%H:%M').time()
                
                new_booking = Booking(
                    property_id=conversation_data['property_id'],
                    customer_name=conversation_data['customer_name'],
                    customer_phone=conversation_data['customer_phone'],
                    date=booking_date,
                    time=booking_time,
                    party_size=conversation_data['party_size'],
                    booking_reference=booking_reference,
                    status='confirmed'
                )
                
                db.session.add(new_booking)
                db.session.commit()
                
                # Store the booking ID and reference in conversation data
                conversation_data['booking_id'] = new_booking.id
                conversation_data['booking_reference'] = booking_reference
                
                # Update the conversation in the database
                conversation = Conversation.query.filter_by(current_state=current_state).first()
                if conversation:
                    conversation.booking_id = new_booking.id
                    conversation.conversation_data = conversation_data
                    db.session.commit()
                
                response = f"Excellent! Your booking has been confirmed. Your booking reference is {booking_reference}. " \
                           f"We look forward to welcoming you to Barbeque Nation {conversation_data['property_name']} " \
                           f"on {booking_date.strftime('%A, %d %B %Y')} at {booking_time.strftime('%I:%M %p')}. " \
                           f"Is there anything else I can help you with today?"
                
                new_state = 'goodbye'
            except Exception as e:
                logger.error(f"Error creating booking: {str(e)}")
                response = "I'm sorry, there was an error processing your booking. Please try again later."
                new_state = 'goodbye'
        else:
            response = "I understand you want to make changes. What would you like to modify about your booking?"
            new_state = 'identify_intent'  # Go back to intent identification
    
    elif current_state == 'booking_lookup':
        # Extract booking reference or phone number from user input
        booking_reference = _extract_booking_reference(user_input)
        phone_number = _extract_phone_number(user_input)
        
        # Look up the booking
        booking = None
        
        if booking_reference:
            booking = Booking.query.filter_by(booking_reference=booking_reference).first()
        elif phone_number:
            # Get the most recent booking for this phone number
            booking = Booking.query.filter_by(customer_phone=phone_number).order_by(Booking.created_at.desc()).first()
        
        if booking:
            # Store the booking ID and reference in conversation data
            conversation_data['booking_id'] = booking.id
            conversation_data['booking_reference'] = booking.booking_reference
            
            # Format the booking details
            property_obj = Property.query.get(booking.property_id)
            property_name = property_obj.name if property_obj else "Unknown Location"
            formatted_date = booking.date.strftime('%A, %d %B %Y')
            formatted_time = booking.time.strftime('%I:%M %p')
            
            booking_details = f"Restaurant: {property_name}\n" \
                              f"Date: {formatted_date}\n" \
                              f"Time: {formatted_time}\n" \
                              f"Party Size: {booking.party_size} people\n" \
                              f"Name: {booking.customer_name}\n" \
                              f"Phone: {booking.customer_phone}\n" \
                              f"Status: {booking.status.capitalize()}\n" \
                              f"Booking Reference: {booking.booking_reference}"
            
            conversation_data['booking_details'] = booking_details
            
            # Check the user's intent
            intent = conversation_data.get('intent')
            
            if intent == 'modify_booking':
                if booking.status == 'cancelled':
                    response = f"I found your booking, but it has already been cancelled. Here are the details:\n\n{booking_details}\n\nWould you like to make a new booking?"
                    new_state = 'identify_intent'
                else:
                    response = f"I found your booking. Here are the details:\n\n{booking_details}\n\nWhat would you like to change? You can modify the date, time, or party size."
                    new_state = 'booking_modification'
            elif intent == 'cancel_booking':
                if booking.status == 'cancelled':
                    response = f"I found your booking, but it has already been cancelled. Here are the details:\n\n{booking_details}\n\nWould you like to make a new booking?"
                    new_state = 'identify_intent'
                else:
                    response = f"I found your booking. Here are the details:\n\n{booking_details}\n\nAre you sure you want to cancel this booking? Please reply with 'yes' to confirm cancellation or 'no' to keep it."
                    new_state = 'booking_cancellation'
            else:
                response = f"I found your booking. Here are the details:\n\n{booking_details}\n\nWould you like to modify or cancel this booking?"
                new_state = 'identify_intent'
        else:
            response = "I'm sorry, I couldn't find a booking with the information provided. Please check and provide the correct booking reference or phone number."
            new_state = 'booking_lookup'  # Stay in the same state
    
    elif current_state == 'booking_modification':
        # Get the booking ID from conversation data
        booking_id = conversation_data.get('booking_id')
        
        if not booking_id:
            response = "I'm sorry, I don't have the booking information. Let's start over."
            new_state = 'identify_intent'
        else:
            booking = Booking.query.get(booking_id)
            
            if not booking:
                response = "I'm sorry, I couldn't find your booking. Let's start over."
                new_state = 'identify_intent'
            else:
                # Extract what the user wants to modify
                modification_type, modification_value = _extract_modification(user_input)
                
                if modification_type == 'date':
                    # Parse the new date
                    try:
                        new_date = datetime.strptime(modification_value, '%Y-%m-%d').date()
                        booking.date = new_date
                        booking.status = 'modified'
                        db.session.commit()
                        
                        formatted_date = new_date.strftime('%A, %d %B %Y')
                        response = f"I've updated your booking date to {formatted_date}. Is there anything else you'd like to change?"
                        new_state = 'booking_modification'
                    except Exception as e:
                        logger.error(f"Error modifying booking date: {str(e)}")
                        response = "I'm sorry, I couldn't update the date. Please provide it in a format like 'tomorrow' or '15th August'."
                        new_state = 'booking_modification'
                
                elif modification_type == 'time':
                    # Parse the new time
                    try:
                        new_time = datetime.strptime(modification_value, '%H:%M').time()
                        booking.time = new_time
                        booking.status = 'modified'
                        db.session.commit()
                        
                        formatted_time = new_time.strftime('%I:%M %p')
                        response = f"I've updated your booking time to {formatted_time}. Is there anything else you'd like to change?"
                        new_state = 'booking_modification'
                    except Exception as e:
                        logger.error(f"Error modifying booking time: {str(e)}")
                        response = "I'm sorry, I couldn't update the time. Please provide it in a format like '7 PM' or '8:30 PM'."
                        new_state = 'booking_modification'
                
                elif modification_type == 'party_size':
                    # Parse the new party size
                    try:
                        new_party_size = int(modification_value)
                        booking.party_size = new_party_size
                        booking.status = 'modified'
                        db.session.commit()
                        
                        response = f"I've updated your party size to {new_party_size} people. Is there anything else you'd like to change?"
                        new_state = 'booking_modification'
                    except Exception as e:
                        logger.error(f"Error modifying booking party size: {str(e)}")
                        response = "I'm sorry, I couldn't update the party size. Please provide a valid number."
                        new_state = 'booking_modification'
                
                elif modification_type == 'done':
                    # User is done with modifications
                    property_obj = Property.query.get(booking.property_id)
                    property_name = property_obj.name if property_obj else "Unknown Location"
                    formatted_date = booking.date.strftime('%A, %d %B %Y')
                    formatted_time = booking.time.strftime('%I:%M %p')
                    
                    response = f"Perfect! Your booking has been updated. Here are the new details:\n\n" \
                               f"Restaurant: {property_name}\n" \
                               f"Date: {formatted_date}\n" \
                               f"Time: {formatted_time}\n" \
                               f"Party Size: {booking.party_size} people\n" \
                               f"Name: {booking.customer_name}\n" \
                               f"Phone: {booking.customer_phone}\n" \
                               f"Status: Modified\n" \
                               f"Booking Reference: {booking.booking_reference}\n\n" \
                               f"Is there anything else I can help you with today?"
                    
                    new_state = 'goodbye'
                
                else:
                    response = "I'm sorry, I didn't understand what you want to modify. You can change the date, time, or party size. Or if you're done with modifications, please let me know."
                    new_state = 'booking_modification'  # Stay in the same state
    
    elif current_state == 'booking_cancellation':
        # Check if the user confirms the cancellation
        if _is_confirmation(user_input):
            # Get the booking ID from conversation data
            booking_id = conversation_data.get('booking_id')
            
            if not booking_id:
                response = "I'm sorry, I don't have the booking information. Let's start over."
                new_state = 'identify_intent'
            else:
                booking = Booking.query.get(booking_id)
                
                if not booking:
                    response = "I'm sorry, I couldn't find your booking. Let's start over."
                    new_state = 'identify_intent'
                else:
                    # Cancel the booking
                    booking.status = 'cancelled'
                    db.session.commit()
                    
                    response = f"I've cancelled your booking with reference {booking.booking_reference}. Would you like to make a new booking or is there anything else I can help you with?"
                    new_state = 'identify_intent'
        else:
            response = "I understand you don't want to cancel your booking. Is there anything else I can help you with?"
            new_state = 'identify_intent'
    
    elif current_state == 'goodbye':
        response = "It was a pleasure assisting you today. If you have any other questions or need to make changes to your booking, feel free to contact us again. Have a wonderful day!"
        new_state = 'identify_intent'  # Reset to the beginning
    
    else:
        logger.error(f"Unknown state: {current_state}")
        response = "I'm sorry, there seems to be an issue with our conversation flow. Let's start over. How can I help you today?"
        new_state = 'greeting'
    
    logger.debug(f"New state: {new_state}, Response: {response}")
    
    # Return the response and new state
    return response, new_state

# Helper functions for intent recognition and entity extraction

def _identify_intent(user_input):
    """Identify the user's intent from their message."""
    user_input = user_input.lower()
    
    # Check for booking-related intents
    if any(word in user_input for word in ['book', 'reservation', 'table', 'new booking', 'reserve']):
        return 'new_booking'
    
    # Check for modification-related intents
    if any(word in user_input for word in ['change', 'modify', 'update', 'reschedule', 'edit']):
        return 'modify_booking'
    
    # Check for cancellation-related intents
    if any(word in user_input for word in ['cancel', 'delete', 'remove']):
        return 'cancel_booking'
    
    # If none of the above, assume it's a question
    return 'faq'

def _extract_location_info(user_input):
    """Extract city and property name from user input."""
    user_input = user_input.lower()
    
    # Check for cities first
    city = None
    if 'delhi' in user_input:
        city = 'Delhi'
    elif 'bangalore' in user_input or 'bengaluru' in user_input:
        city = 'Bangalore'
    
    # Attempt to extract property name (placeholder logic)
    property_name = None
    # This would be more sophisticated in a real implementation
    # Here we're just looking for patterns like "X branch" or "X location"
    if city:
        # Split the input and check for words after city name
        words = user_input.split()
        city_idx = -1
        
        for i, word in enumerate(words):
            if city.lower() in word:
                city_idx = i
                break
        
        if city_idx != -1 and city_idx < len(words) - 1:
            # Look for property name patterns after city name
            property_name = ' '.join(words[city_idx+1:])
    
    return city, property_name

def _extract_date_time(user_input):
    """
    Extract date and time from user input.
    
    This is a simplified implementation. In a real system, you would use a more sophisticated
    NLP approach for date/time extraction, like spaCy or dedicated date parsing libraries.
    """
    user_input = user_input.lower()
    
    # Initialize date and time to None
    extracted_date = None
    extracted_time = None
    
    # Simple date extraction
    today = datetime.now().date()
    
    if 'today' in user_input:
        extracted_date = today
    elif 'tomorrow' in user_input:
        extracted_date = today + timedelta(days=1)
    elif 'day after tomorrow' in user_input:
        extracted_date = today + timedelta(days=2)
    else:
        # This is a very simplified approach - a real implementation would be more robust
        # Try to extract date patterns (e.g., 15th August, 2023-08-15)
        # For demonstration purposes only
        import re
        from dateutil import parser as date_parser
        
        # Try to find date patterns
        date_patterns = [
            r'\d{1,2}(?:st|nd|rd|th)? [A-Za-z]+',  # 15th August
            r'\d{4}-\d{2}-\d{2}',  # 2023-08-15
            r'\d{1,2}/\d{1,2}(?:/\d{2,4})?'  # 15/08 or 15/08/2023
        ]
        
        for pattern in date_patterns:
            match = re.search(pattern, user_input)
            if match:
                try:
                    date_str = match.group(0)
                    parsed_date = date_parser.parse(date_str, fuzzy=True).date()
                    extracted_date = parsed_date
                    break
                except:
                    pass
    
    # Simple time extraction
    time_patterns = [
        r'(\d{1,2})(?::(\d{2}))?\s*(am|pm)',  # 7:30 pm
        r'(\d{1,2})(?::(\d{2}))?(?:\s*o\'?clock)?'  # 7:30 or 7 o'clock
    ]
    
    import re
    for pattern in time_patterns:
        match = re.search(pattern, user_input, re.IGNORECASE)
        if match:
            try:
                hour = int(match.group(1))
                minute = int(match.group(2)) if match.group(2) else 0
                
                # Adjust for am/pm
                if match.group(3) and match.group(3).lower() == 'pm' and hour < 12:
                    hour += 12
                
                from datetime import time
                extracted_time = time(hour, minute)
                break
            except:
                pass
    
    return extracted_date, extracted_time

def _extract_party_size(user_input):
    """Extract party size from user input."""
    user_input = user_input.lower()
    
    # Try to find a number
    import re
    number_patterns = [
        r'(\d+)\s*people',
        r'(\d+)\s*persons',
        r'(\d+)\s*guests',
        r'party\s*of\s*(\d+)',
        r'table\s*for\s*(\d+)',
        r'(\d+)'  # Fallback pattern
    ]
    
    for pattern in number_patterns:
        match = re.search(pattern, user_input)
        if match:
            try:
                return int(match.group(1))
            except:
                pass
    
    # Handle textual numbers (one, two, etc.)
    textual_numbers = {
        'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5,
        'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10
    }
    
    for word, number in textual_numbers.items():
        if word in user_input:
            return number
    
    return None

def _extract_contact_info(user_input):
    """Extract name and phone number from user input."""
    # This is a simplified implementation
    name = None
    phone_number = None
    
    # Try to extract a name (first word that's not a common preposition/article)
    words = user_input.split()
    stopwords = ['my', 'name', 'is', 'i', 'am', 'the', 'this', 'that', 'and', 'or', 'but', 'with', 'phone', 'number']
    
    for word in words:
        if word.lower() not in stopwords and word.isalpha():
            name = word
            break
    
    # Try to extract a phone number
    import re
    phone_patterns = [
        r'(\d{10})',  # 10 digits
        r'(\d{3}[-.\s]\d{3}[-.\s]\d{4})',  # 123-456-7890
        r'(\(\d{3}\)\s*\d{3}[-.\s]\d{4})'  # (123) 456-7890
    ]
    
    for pattern in phone_patterns:
        match = re.search(pattern, user_input)
        if match:
            phone_number = match.group(1)
            # Remove any non-digit characters
            phone_number = re.sub(r'\D', '', phone_number)
            break
    
    return name, phone_number

def _is_confirmation(user_input):
    """Check if the user's input is a confirmation (yes/ok/sure)."""
    user_input = user_input.lower()
    confirmation_words = ['yes', 'yeah', 'sure', 'ok', 'okay', 'correct', 'right', 'confirm', 'perfect', 'good']
    
    return any(word in user_input for word in confirmation_words)

def _extract_booking_reference(user_input):
    """Extract booking reference from user input."""
    import re
    # Assuming booking references are in format BBQ-XXXXXX
    match = re.search(r'BBQ-[A-Z0-9]{6}', user_input.upper())
    
    if match:
        return match.group(0)
    
    return None

def _extract_phone_number(user_input):
    """Extract phone number from user input."""
    import re
    
    # Try to extract a phone number
    phone_patterns = [
        r'(\d{10})',  # 10 digits
        r'(\d{3}[-.\s]\d{3}[-.\s]\d{4})',  # 123-456-7890
        r'(\(\d{3}\)\s*\d{3}[-.\s]\d{4})'  # (123) 456-7890
    ]
    
    for pattern in phone_patterns:
        match = re.search(pattern, user_input)
        if match:
            phone_number = match.group(1)
            # Remove any non-digit characters
            phone_number = re.sub(r'\D', '', phone_number)
            return phone_number
    
    return None

def _extract_modification(user_input):
    """
    Extract what the user wants to modify and the new value.
    
    Returns:
        tuple: (modification_type, modification_value)
          - modification_type: 'date', 'time', 'party_size', or 'done'
          - modification_value: The new value for the modification
    """
    user_input = user_input.lower()
    
    # Check if the user is done with modifications
    if any(word in user_input for word in ['done', 'that\'s all', 'nothing else', 'finished', 'complete']):
        return 'done', None
    
    # Check for date modification
    if any(word in user_input for word in ['date', 'day', 'reschedule']):
        date, _ = _extract_date_time(user_input)
        if date:
            return 'date', date.strftime('%Y-%m-%d')
    
    # Check for time modification
    if any(word in user_input for word in ['time', 'hour', 'clock']):
        _, time = _extract_date_time(user_input)
        if time:
            return 'time', time.strftime('%H:%M')
    
    # Check for party size modification
    if any(phrase in user_input for phrase in ['party size', 'number of people', 'how many people', 'guest count']):
        party_size = _extract_party_size(user_input)
        if party_size:
            return 'party_size', str(party_size)
    
    # If no specific modification was identified
    return None, None
