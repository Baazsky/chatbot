"""
Script to seed the database with initial data for testing.
Run this file to populate the database with sample properties and FAQs.
"""
import logging
from app import app, db, init_app
from models import Property, FAQ
from datetime import datetime

logger = logging.getLogger(__name__)

# Sample properties data (Barbeque Nation locations)
properties = [
    {
        "name": "Barbeque Nation - Connaught Place",
        "city": "Delhi",
        "address": "P-2/90, Connaught Circus, Block P, Connaught Place, New Delhi, Delhi 110001",
        "contact_number": "9212340202",
        "opening_hours": "12:00 PM - 11:00 PM"
    },
    {
        "name": "Barbeque Nation - Janakpuri",
        "city": "Delhi",
        "address": "3rd Floor, Unity One Mall, Janakpuri District Centre, Janakpuri, New Delhi, Delhi 110058",
        "contact_number": "9311748899",
        "opening_hours": "12:00 PM - 11:00 PM"
    },
    {
        "name": "Barbeque Nation - Pitampura",
        "city": "Delhi",
        "address": "3rd Floor, Unity One Rohini, Plot No. 3, Rohini, New Delhi, Delhi 110085",
        "contact_number": "9599131267",
        "opening_hours": "12:00 PM - 11:00 PM"
    },
    {
        "name": "Barbeque Nation - Koramangala",
        "city": "Bangalore",
        "address": "No. 139, 1st Cross, Koramangala 5th Block, Bangalore, Karnataka 560095",
        "contact_number": "9902099215",
        "opening_hours": "12:00 PM - 11:00 PM"
    },
    {
        "name": "Barbeque Nation - Indiranagar",
        "city": "Bangalore",
        "address": "No. 1, 100 Feet Road, HAL II Stage, Indiranagar, Bangalore, Karnataka 560038",
        "contact_number": "9902099216",
        "opening_hours": "12:00 PM - 11:00 PM"
    },
    {
        "name": "Barbeque Nation - Whitefield",
        "city": "Bangalore",
        "address": "Ground Floor, Phoenix Marketcity, Whitefield Road, Mahadevapura, Bangalore, Karnataka 560048",
        "contact_number": "9902099217",
        "opening_hours": "12:00 PM - 11:00 PM"
    }
]

# Sample FAQs (General and property-specific)
faqs = [
    # General FAQs (apply to all properties)
    {
        "question": "What is the cost of the buffet?",
        "answer": "Our lunch buffet starts at ₹799 plus taxes and dinner buffet starts at ₹899 plus taxes. The exact price may vary by location and special festival offerings. Please check with the specific outlet for current prices.",
        "category": "pricing",
        "is_general": True
    },
    {
        "question": "Do you offer veg and non-veg options?",
        "answer": "Yes, we offer both vegetarian and non-vegetarian options in our buffet. Our menu includes a wide variety of both veg and non-veg starters, main course items, and desserts.",
        "category": "menu",
        "is_general": True
    },
    {
        "question": "Do I need to make a reservation?",
        "answer": "Yes, we highly recommend making a reservation, especially during weekends and holidays. You can make a reservation through our website, by calling the outlet directly, or through this chatbot.",
        "category": "booking",
        "is_general": True
    },
    {
        "question": "What is your cancellation policy?",
        "answer": "You can cancel your reservation up to 2 hours before the booking time without any charges. For cancellations made less than 2 hours before the booking, we may require a reason for the cancellation.",
        "category": "booking",
        "is_general": True
    },
    {
        "question": "Do you have any special offers for birthdays or anniversaries?",
        "answer": "Yes, we offer a complimentary cake for birthday and anniversary celebrations. Please mention it at the time of booking so we can arrange it for you.",
        "category": "offers",
        "is_general": True
    },
    # Delhi-specific FAQs (set property_id after creating properties)
    {
        "question": "Is parking available at Connaught Place outlet?",
        "answer": "There is no dedicated parking for the restaurant, but paid parking is available in Connaught Place. We recommend using public transport or ride-sharing services, especially during peak hours.",
        "category": "facilities",
        "is_general": False,
        "property_name": "Barbeque Nation - Connaught Place"
    },
    {
        "question": "Is the Janakpuri outlet accessible by metro?",
        "answer": "Yes, our Janakpuri outlet is easily accessible by metro. It's located at Unity One Mall which is just a 5-minute walk from Janakpuri West Metro Station (Blue Line and Magenta Line).",
        "category": "location",
        "is_general": False,
        "property_name": "Barbeque Nation - Janakpuri"
    },
    # Bangalore-specific FAQs (set property_id after creating properties)
    {
        "question": "Does the Indiranagar outlet serve alcohol?",
        "answer": "Yes, our Indiranagar outlet has a full bar service offering a variety of alcoholic beverages including beer, wine, and cocktails. These are charged separately from the buffet price.",
        "category": "menu",
        "is_general": False,
        "property_name": "Barbeque Nation - Indiranagar"
    },
    {
        "question": "Is the Koramangala outlet suitable for a corporate event?",
        "answer": "Yes, our Koramangala outlet has a private dining area that can accommodate corporate events of up to 40 people. Please contact the restaurant directly to discuss your requirements and make arrangements.",
        "category": "facilities",
        "is_general": False,
        "property_name": "Barbeque Nation - Koramangala"
    }
]

def seed_database():
    """Seed the database with sample data"""
    try:
        # Create Property records
        property_objects = {}
        
        for property_data in properties:
            # Check if property already exists
            existing = Property.query.filter_by(name=property_data["name"]).first()
            if existing:
                logger.info(f"Property already exists: {property_data['name']}")
                property_objects[property_data["name"]] = existing
                continue
            
            # Create new property
            new_property = Property(
                name=property_data["name"],
                city=property_data["city"],
                address=property_data["address"],
                contact_number=property_data["contact_number"],
                opening_hours=property_data["opening_hours"],
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            db.session.add(new_property)
            logger.info(f"Added property: {property_data['name']}")
            
            # Commit to get the ID
            db.session.commit()
            property_objects[property_data["name"]] = new_property
        
        # Create FAQ records
        for faq_data in faqs:
            # Set property_id for property-specific FAQs
            property_id = None
            if not faq_data.get("is_general", False) and "property_name" in faq_data:
                property_name = faq_data.pop("property_name")
                if property_name in property_objects:
                    property_id = property_objects[property_name].id
            
            # Check if FAQ already exists
            existing = FAQ.query.filter_by(
                question=faq_data["question"],
                property_id=property_id
            ).first()
            
            if existing:
                logger.info(f"FAQ already exists: {faq_data['question']}")
                continue
            
            # Create new FAQ
            new_faq = FAQ(
                question=faq_data["question"],
                answer=faq_data["answer"],
                category=faq_data["category"],
                property_id=property_id,
                is_general=faq_data.get("is_general", False),
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            db.session.add(new_faq)
            logger.info(f"Added FAQ: {faq_data['question']}")
        
        # Commit all changes
        db.session.commit()
        logger.info("Database seeded successfully")
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error seeding database: {str(e)}")
        raise

if __name__ == "__main__":
    # Initialize the app
    app = init_app()
    
    # Seed the database
    with app.app_context():
        seed_database()